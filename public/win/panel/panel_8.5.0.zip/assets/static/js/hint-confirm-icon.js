const n=""+new URL("../icons/hint-confirm-icon.svg",import.meta.url).href;export{n as _};
