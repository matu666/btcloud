function CreateWebsiteModel(config) {
  this.type = config.type;
  this.tips = config.tips;
  this.methods = {
    createProject: ['create_project', '创建' + config.tips + '项目'],
    modifyProject: ['modify_project', '修改' + config.tips + '项目'],
    removeProject: ['remove_project', '删除' + config.tips + '项目'],
    startProject: ['start_project', '启动' + config.tips + '项目'],
    stopProject: ['stop_project', '停止' + config.tips + '项目'],
    restartProject: ['restart_project', '重启' + config.tips + '项目'],
    getProjectInfo: ['get_project_info', '获取' + config.tips + '项目信息'],
    getProjectDomain: ['project_get_domain', '获取' + config.tips + '项目域名'],
    addProjectDomain: ['add_domain', '添加' + config.tips + '项目域名'],
    removeProjectDomain: [
      'project_remove_domain',
      '删除' + config.tips + '项目域名',
    ],
    getProjectLog: ['get_project_log', '获取' + config.tips + '项目日志'],
    change_log_path: ['change_log_path', '修改' + config.tips + '项目日志路径'],
    get_log_split: ['get_log_split', '获取' + config.tips + '项目日志切割任务'],
    mamger_log_split: ['mamger_log_split', '设置' + config.tips + '项目日志切割任务'],
    set_log_split: ['set_log_split', '设置' + config.tips + '项目日志切割状态'],
    bindExtranet: ['bind_extranet', '开启外网映射'],
    unbindExtranet: ['unbind_extranet', '关闭外网映射'],
  };
  this.bindHttp(); //将请求映射到对象
  this.reanderProjectList(); // 渲染列表
}
/**
 * @description 渲染获取项目列表
 */
CreateWebsiteModel.prototype.reanderProjectList = function () {
  var _that = this;
  $('#bt_' + this.type + '_table').empty();
  site.model_table = bt_tools.table({
    el: '#bt_' + this.type + '_table',
    url: '/project/proxy/get_list',
    minWidth: '1000px',
    autoHeight: true,
    default: '项目列表为空', //数据为空时的默认提示\
    load: '正在获取' + _that.tips + '项目列表，请稍候...',
    pageName: 'nodejs',
    beforeRequest: function (params) {
      return { data: JSON.stringify(params) };
    },
    dataVerify: false,
    dataFilter: function (res) {
      return res.data
    },
    column: [
      { type: 'checkbox', class: '', width: 20 },
      {
        fid: 'name',
        title: '域名',
        type: 'link',
        event: function (row, index, ev) {
          _that.reanderProjectInfoView(row);
        },
      },
      {
        fid: 'proxy_pass',
        title: '代理地址',
        width: 220,
        type: 'link',
        event:function(row,index,ev){
          _that.reanderProjectInfoView(row);
          setTimeout(function () {
            $('.proxy-menu p:eq(1)').click();
          }, 500);
        },
      },
      {
        fid: 'ps',
        title: '备注',
        type: 'input',
        blur: function (row, index, ev, key, that) {
          if (row.ps == ev.target.value) return false;
          bt.pub.set_data_ps(
            { id: row.id, table: 'sites', ps: ev.target.value },
            function (res) {
              bt_tools.msg(res, { is_dynamic: true });
            }
          );
        },
        keyup: function (row, index, ev) {
          if (ev.keyCode === 13) {
            $(this).blur();
          }
        },
      },
      {
        fid: 'ssl',
        title: 'SSL证书',
        tips: '部署证书',
        width: 100,
        type: 'text',
        template: function (row, index) {
          var _ssl = row.ssl,
            _info = '',
            _arry = [
              ['issuer', '证书品牌'],
              ['notAfter', '到期日期'],
              ['notBefore', '申请日期'],
              ['dns', '可用域名'],
            ];
          try {
            if (typeof row.ssl.endtime != 'undefined') {
              if (row.ssl.endtime < 1) {
                return '<a class="btlink bt_danger" href="javascript:;">已过期</a>';
              }
            }
          } catch (error) {}
          for (var i = 0; i < _arry.length; i++) {
            var item = _ssl[_arry[i][0]];
            _info += _arry[i][1] + ':' + item + (_arry.length - 1 != i ? '\n' : '');
          }
          return row.ssl === -1
            ? '<a class="btlink bt_warning" href="javascript:;">未部署</a>'
            : '<a class="btlink ' + (row.ssl.endtime < 7 ? 'bt_danger' : '') + '" href="javascript:;" title="' + _info + '">剩余' + row.ssl.endtime + '天</a>';
        },
        event: function (row) {
          _that.reanderProjectInfoView(row);
          setTimeout(function () {
            $('.proxy-menu p:eq(4)').click();
          }, 500);
        },
      },
      {
        title: '操作',
        type: 'group',
        width: 100,
        align: 'right',
        group: [
          {
            title: '设置',
            event: function (row, index, ev, key, that) {
              _that.reanderProjectInfoView(row);
            },
          },
          {
            title: '删除',
            event: function (row, index, ev, key, that) {
              bt.simple_confirm({
                title: '删除反向代理 - [' + row.name + ']',
                msg: '<div class="break-all mb20"><span class="color-org">风险操作，此操作不可逆</span>，删除【' + row.name + '】项目后您将无法管理该项目，是否继续操作？</div>\
                <input type="checkbox" name="remove_path" id="remove_path" /><label class="ml5" for="remove_path">同时删除网站根目录</label>'},
                function () {
                  bt_tools.send({
                    url:'/project/proxy/delete',
                    data: {
                      data: JSON.stringify({
                        id: row.id,
                        site_name: row.name,
                        remove_path: $('#remove_path').prop('checked') ? 1 : 0
                      })
                    }
                  }, function (res){
                    if(res!=null){
                      bt.msg({status:res.status,msg:res.msg})
                      site.model_table.$refresh_table_list(true);
                    }
                  })
                }
              );
            },
          },
        ],
      },
    ],
    // 渲染完成
    tootls: [
      {
        // 按钮组
        type: 'group',
        positon: ['left', 'top'],
        list: [
          {
            title: '添加反代',
            active: true,
            event: function (ev) {
              _that.reanderAddProject(function (res) {
                site.model_table.$refresh_table_list(true);
              });
            },
          },
        ],
      },
      {
        // 搜索内容
        type: 'search',
        positon: ['right', 'top'],
        placeholder: '请输入项目名称或备注',
        searchParam: 'search', //搜索请求字段，默认为 search
        value: '', // 当前内容,默认为空
      },
      {
        // 批量操作
        type: 'batch', //batch_btn
        positon: ['left', 'bottom'],
        placeholder: '请选择批量操作',
        buttonValue: '批量操作',
        disabledSelectValue: '请选择需要批量操作的站点!',
        selectList: [
          // {
          // 	title: '部署证书',
          // 	callback: function (that) {
          // 		site.set_ssl_cert(that);
          // 	},
          // },
          {
            title: '删除项目',
            url: '/project/proxy/delete',
            param: function (row) {
              return {
                data: JSON.stringify({
                  id: row.id,
                  site_name: row.name,
                  remove_path: row.remove_path
                })
              }
            },
            refresh: true,
            callback: function (that) {
              bt.simple_confirm({
                title: '批量删除反向代理规则',
                msg: '<div class="break-all mb20">批量删除选中的项目后，项目将无法恢复，是否继续操作？</div>\
                <input type="checkbox" name="remove_path" id="remove_path" /><label class="ml5" for="remove_path">同时删除网站根目录</label>'},
                function () {
                  that.check_list = that.check_list.map(function (item) {
                    return $.extend(item, {
                      remove_path: $('#remove_path').prop('checked') ? 1 : 0
                    })
                  })
                  that.start_batch({}, function (list) {
                    var html = '';
                    for (var i = 0; i < list.length; i++) {
                      var item = list[i];
                      html +=
                        '<tr><td><span>' +
                        item.name +
                        '</span></td><td><div style="float:right;"><span style="color:' +
                        (item.requests.status ? '#20a53a' : 'red') +
                        '">' +
                        (item.requests.status
                          ? item.requests.msg
                          : item.requests.msg) +
                        '</span></div></td></tr>';
                    }
                    site.model_table.$batch_success_table({
                      title: '批量删除项目',
                      th: '项目名称',
                      html: html,
                    });
                    site.model_table.$refresh_table_list(true);
                  });
                }
              );
            },
          }
        ],
      },
      {
        //分页显示
        type: 'page',
        positon: ['right', 'bottom'], // 默认在右下角
        pageParam: 'p', //分页请求字段,默认为 : p
        page: 1, //当前分页 默认：1
        numberParam: 'limit',
        //分页数量请求字段默认为 : limit
        number: 20,
        //分页数量默认 : 20条
        numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
        numberStatus: true, //　是否支持分页数量选择,默认禁用
        jump: true, //是否支持跳转分页,默认禁用
      },
    ],
    success: function () {
      // 刷新
      site.reader_model_refresh('proxy')
      $('#bt_proxy_table .table-search-result').remove()
    }
  });
};

/**
 * @description 获取添加项目配置
 */
CreateWebsiteModel.prototype.getAddProjectConfig = function (data) {
  var that = this,
    data = data || {},
    config = [
      {
        label: '绑定域名',
        formLabelWidth: '120px',
        must: '*',
        group: {
          type: 'textarea', //当前表单的类型 支持所有常规表单元素、和复合型的组合表单元素
          name: 'domains', //当前表单的name
          style: { width: '440px', height: '120px', 'line-height': '22px' },
          tips: {
            //使用hover的方式显示提示
            text: '如需填写多个域名，请换行填写，每行一个域名，默认为80端口<br>IP地址格式：192.168.1.199<br>泛解析添加方法：先添加一个域名 domain.com，后换行添加*.domain.com<br>如另加端口格式为 www.domain.com:88',
            style: { top: '10px', left: '15px' },
          },
          input: function (value, form, thats, config, ev) {
            //键盘事件
            var array = value.domains.split('\n'),
              ress = array[0].split(':')[0],
              is_oneVal = ress.length > 0;
            thats.$set_find_value({
              remark: is_oneVal ? ress : '',
            });
          },
        },
      },
      {
        label: '目标',
        formLabelWidth: '120px',
        must: '*',
        group: [
          {
            type: 'select',
            name: 'targetType',
            width: '160px',
            list: [
              {
                title: 'URL地址',
                value: 'url'
              },
              // {
              //   title: 'unix地址',
              //   value: 'unix'
              // }
            ],
            change: function (formData, element, _that) {
              var isUrl = formData.targetType == 'url'
              var proxysite_config = _that.config.form[1].group[1]
              proxysite_config.placeholder = isUrl ? '请输入目标地址' : '请选择sock文件'
              proxysite_config.value = isUrl ? 'http://' : ''
              proxysite_config.icon = {
                type: 'glyphicon-folder-open',
                select: 'file',
                event: function (ev) {},
              }
              if (isUrl) delete proxysite_config.icon
              _that.$replace_render_content(1)
            }
          },
          {
            type: 'text',
            name: 'proxysite',
            placeholder: '请输入目标地址',
            width: '270px',
            value: 'http://',
            input: function (formData, element, _that) {
              var todomain_config = _that.config.form[2].group
              var value = formData.proxysite.replace(/^http[s]?:\/\//, '')
	            value = value.replace(/(:|\?|\/|\\)(.*)$/, '')
              todomain_config.value = formData.targetType === 'unix' ? '$http_host' : value
              _that.$replace_render_content(2)
            }
          }
        ]
      },
      {
        label: '发送域名(host)',
        formLabelWidth: '120px',
        must: '*',
        group: {
          type: 'text',
          name: 'todomain',
          width: '440px',
          placeholder: '请输入发送域名',
          value: '',
        },
      },
      {
        label: '备注',
        formLabelWidth: '120px',
        group: {
          type: 'text',
          name: 'remark',
          width: '440px',
          placeholder: '请输入备注，可为空',
          value: '',
        },
      },
      {
        formLabelWidth: '0px',
        group: {
          type: 'help',
          list: [
            '目标：可以填写你需要代理的站点，目标如果选URL地址则必须为可正常访问的URL',//，如果选UNIX则必须是套接字文件
            'http地址示例：http://127.0.0.1:15700',
            // 'unix地址示例：/tmp/panel.sock',
            '发送域名：将域名添加到请求头传递到后端服务器，默认为目标URL域名，若设置不当可能导致代理无法正常访问，例如：<br>\
            http://192.168.100.20:19888，则发送域名保持$http_host即可<br>\
            http://www.bt.cn，则发送域名应当改为www.bt.cn<br>\
            上面例子仅为常见情况，请以实际为准'
          ]
        }
      }
    ];
  return config;
};

/**
 * @description 渲染添加项目表单
 */
CreateWebsiteModel.prototype.reanderAddProject = function (callback) {
  var that = this;

  var modelForm = bt_tools.open({
    title: '添加' + this.tips + '项目',
    area: '726px',
    btn: ['提交', '取消'],
    content: {
      class: 'pd30',
      formLabelWidth: '120px',
      form: (function () {
        return that.getAddProjectConfig();
      })(),
    },
    success: function (layers, index) {
      $('[name="proxysite"]').keyup(function () {
        var val = $(this).val(),
          ip_reg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
        val = val.replace(/^http[s]?:\/\//, '');
        // val = val.replace(/:([0-9]*)$/, '');
        val = val.replace(/(:|\?|\/|\\)(.*)$/, '');
        if (ip_reg.test(val)) {
          $("[name='todomain']").val('$host');
        } else {
          $("[name='todomain']").val(val);
        }
      });

      $('[name=todomain]').focus(function () {
        layer.tips('请求转发到后端服务器时的主机名，一般为$http_host，如果目标URL是域名，则需要改为域名', $(this), { tips: [1, '#666'], time: 0, area: '440px' });
      })
      $('[name=todomain]').blur(function () {
        layer.closeAll('tips');
      })
    },
    yes: function (formData, indexs, layero) {
      if (formData.domains != '') {
        var arry = formData.domains.replace(/\n/g, '').split('\r'),
          newArry = [];
        for (var i = 0; i < arry.length; i++) {
          var item = arry[i];
          if (bt.check_domain_port(item)) {
            newArry.push(item.indexOf(':') > -1 ? item : item + ':80');
          } else {
            bt.msg({ status: false, msg: '【' + item + '】 绑定域名格式错误' });
            return false;
          }
        }
        formData.bind_extranet = 1;
        formData.domains = newArry;
      } else {
        bt.msg({ status: false, msg: '【绑定域名】 不能为空' });
        return
      }
      function isValidUrl(url) {
        var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
          '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name and extension
          '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
          '(\\:\\d+)?'+ // port
          '(\\/[-a-z\\d%@_.~+&:]*)*'+ // path
          '(\\?[;&a-z\\d%@_.,~+&:=-]*)?'+ // query string
          '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
        return pattern.test(url);
      }
      if (formData.targetType === 'url' && !formData.proxysite) {
        bt.msg({ status: false, msg: '【目标URL】 不能为空' });
        return
      }
      if (formData.targetType === 'unix' && !formData.proxysite) {
        bt.msg({ status: false, msg: '请选择sock文件' });
        return
      }
      var todomain = $(layero).find('[name="todomain"]');
      if (todomain.val() != '') {
        formData.todomain = todomain.val();
      }else {
        bt.msg({ status: false, msg: '【发送域名】 不能为空' });
        return
      }
      
      bt_tools.send({url: '/project/proxy/create', data: { data: JSON.stringify({
        remark: formData.remark,
        proxy_type: formData.targetType === 'url' ? 'http' : 'unix',
        proxy_pass: formData.proxysite,
        domains: formData.domains,
        proxy_host: formData.todomain,
      }) }}, function (res) {
        bt_tools.msg(res)
        if (res.status) layer.close(indexs)
        if (callback) callback(res)
      }, '添加反向代理')
    },
  });
};

/**
 * @description 模拟点击
 */
CreateWebsiteModel.prototype.simulatedClick = function (num) {
  $('.bt-w-menu p:eq(' + num + ')').click();
};

/**
 * @description
 * @param {string} name 站点名称
 */
CreateWebsiteModel.prototype.reanderProjectInfoView = function (row) {
  var that = this;
  var item = row;
  bt.open({
    type: 1,
    area: ['836px', '725px'],
    title: lan.site.website_change + '[' + item.name + ']  --  ' + lan.site.addtime + '[' + item.addtime + ']',
    closeBtn: 2,
    shift: 0,
    content:
      "<div class='bt-tabs'>\
        <div class='bt-w-menu proxy-menu pull-left' style='height: 100%;width: 126px;'></div>\
        <div id='webedit-con' class='bt-w-con webedit-con pd15' style='margin-left: 126px;'></div>\
      </div>",
  });
  setTimeout(function () {
    // var webcache = bt.get_cookie('serverType') == 'openlitespeed' ? { title: 'LS-Cache', callback: site.edit.ols_cache } : '';
    var menus = [
      { title: '域名管理', callback: function(web){ CreateWebsiteModel.prototype.reanderDomainManageView($('#webedit-con'), web) } },
			{ title: 'URL代理', callback: CreateWebsiteModel.prototype.url_proxy },
      { title: '全局配置', callback: CreateWebsiteModel.prototype.global_config },
      { title: '配置文件', callback: CreateWebsiteModel.prototype.config_files },
      { title: 'SSL', callback: site.edit.set_ssl },
      { title: '重定向', callback: function(web){ that.reander_project_redirect(web,that)} },
      { title: '防盗链', callback: CreateWebsiteModel.prototype.set_security },
      { title: '日志', callback: CreateWebsiteModel.prototype.get_site_logs },
    ];
    // if (webcache !== '') menus.splice(3, 0, webcache);
    for (var i = 0; i < menus.length; i++) {
      var men = menus[i];
      var _p = $('<p>' + men.title + '</p>');
      _p.data('callback', men.callback);
      $('.proxy-menu').append(_p);
    }
    $('.proxy-menu p').css('padding-left', '36px');
    $('.proxy-menu p').click(function () {
      $('#webedit-con').html('');
      $(this).addClass('bgw').siblings().removeClass('bgw');
      var callback = $(this).data('callback');
      if (callback) callback(item);
    });
    var _sel = $('.proxy-menu p.bgw');
    if (_sel.length == 0) _sel = $('.proxy-menu p').eq(0);
    _sel.trigger('click');
  }, 100);
};

/**
 * @description URL代理
 */
CreateWebsiteModel.prototype.url_proxy = function (web) {
  var _this = this
  $('#webedit-con').append('<div id="url-proxt-table"></div>');
  $('#url-proxt-table').empty()
  bt_tools.table({
    el: '#url-proxt-table',
    url: '/project/proxy/get_proxy_list',
    param: {
      data: JSON.stringify({site_name: web.name,})
    },
    load: true,
    height: 540,
    dataFilter: function (res) {
      return {
        data: res.data
      }
    },
    column: [
      {
        fid: 'proxy_path',
        title: '代理目录'
      },
      {
        fid: 'proxy_pass',
        title: '目标'
      },
      {
        fid: 'remark',
        title: '备注',
        type: 'input',
        width: 200,
        blur: function (row, index, ev, key, that) {
          if (row.remark == ev.target.value) return false;
          bt_tools.send({url: '/project/proxy/set_url_remark', data: {
            data: JSON.stringify({
              site_name: web.name,
              proxy_path: row.proxy_path,
              remark: ev.target.value
            })
          }}, function (res) {
            bt_tools.msg(res, { is_dynamic: true });
          })
        },
        keyup: function (row, index, ev) {
          if (ev.keyCode === 13) {
            $(this).blur();
          }
        },
      },
      {
        title: '操作',
        align: 'right',
        type: 'group',
        width: 100,
        group: [
          {
            title: '设置',
            event: function (row, index, ev, key, that) {
              CreateWebsiteModel.prototype.url_setting(row, web, that)
            }
          },
          {
            title: '删除',
            event: function (row, index, ev, key, that) {
              if (row.proxy_path === '/') bt.msg({ status: false, msg: '根目录不能删除' })
              bt.simple_confirm({title: '删除反向代理【'+ row.proxy_path +'】', msg: '您真的要删除反向代理【'+ row.proxy_path +'】吗？'}, function () {
                bt_tools.send({url: '/project/proxy/del_url_proxy', data: {
                  data: JSON.stringify({
                    site_name: web.name,
                    proxy_path: row.proxy_path,
                  })
                }}, function (res) {
                  bt.msg(res)
                  if (res.status) that.$refresh_table_list()
                }, '删除反向代理')
              })
            }
          }
        ]
      },
    ],
    // 渲染完成
    tootls: [
      {
        // 按钮组
        type: 'group',
        positon: ['left', 'top'],
        list: [
          {
            title: '添加URL代理',
            active: true,
            event: function (ev, that) {
              bt_tools.open({
                title: '添加URL代理',
                area: '726px',
                btn: ['提交', '取消'],
                content: {
                  class: 'pd30',
                  formLabelWidth: '120px',
                  form:(function () {
                    var arr = CreateWebsiteModel.prototype.getAddProjectConfig()
                    // 去除第一个
                    arr.shift();
                    arr.unshift({
                      label: '代理目录',
                      must: '*',
                      group: {
                        type: 'text',
                        placeholder: '请输入代理目录，例如：/web',
                        name: 'proxy_path',
                        width: '440px'
                      }
                    })
                    return arr;
                  })(),
                },
                success: function (layers, index) {
                  $('[name=todomain]').focus(function () {
                    layer.tips('请求转发到后端服务器时的主机名，一般为$http_host，如果目标URL是域名，则需要改为域名', $(this), { tips: [1, '#666'], time: 0, area: '440px' });
                  })
                  $('[name=todomain]').blur(function () {
                    layer.closeAll('tips');
                  })
                },
                yes: function (formData, indexs) {
                  if (formData.targetType === 'url' && !formData.proxysite) {
                    bt.msg({ status: false, msg: '【目标URL】 格式错误' });
                    return
                  }
                  if (formData.targetType === 'unix' && !formData.proxysite) {
                    bt.msg({ status: false, msg: '请选择sock文件' });
                    return
                  }
                  if (!formData.todomain) {
                    bt.msg({ status: false, msg: '【发送域名】 不能为空' });
                    return
                  }
                  
                  bt_tools.send({url: '/project/proxy/add_proxy', data: {
                    data: JSON.stringify({
                      site_name: web.name,
                      remark: formData.remark,
                      proxy_type: formData.targetType === 'url' ? 'http' : 'unix',
                      proxy_pass: formData.proxysite,
                      proxy_path: formData.proxy_path,
                      proxy_host: formData.todomain,
                    })
                  }}, function (res) {
                    bt_tools.msg(res)
                    if (res.status) {
                      that.$refresh_table_list()
                      layer.close(indexs)
                    }
                  }, '添加URL代理')
                } 
              })
            },
          },
        ],
      },
    ]
  })
};

/**
 * @description url反代 设置 配置
 * @param {*} data 
 * @param {*} callabck 
 */
CreateWebsiteModel.prototype.request_config = function (data, callabck) {
  bt_tools.send({url: '/project/proxy/get_proxy_list', data}, function (res) {
    if (callabck) callabck(res.data)
  }, '获取数据')
}

/**
 * @description url反代 设置
 * @param {*} row url反代 行数据
 */
CreateWebsiteModel.prototype.url_setting = function (row, web, that) {
  var _this = this
  var param = {
    data: JSON.stringify({
      site_name: web.name,
      proxy_path: row.proxy_path,
    })
  }
  bt_tools.open({
    type: 1,
    title: 'URL代理设置【'+ row.proxy_path +'】',
    area: ['760px', '630px'],
    btn: false,
    content: '<div class="pd20"><div id="url-setting-box" class="tab-nav"></div><div class="tab-con" style="padding:10px 0px;"></div></div>',
    success: function (layero) {
      var _tab = [
        {
          title: '反向代理',
          callback: function (robj) {
            robj.html('<div class="proxy-form pd20 custom-form"></div>')
            CreateWebsiteModel.prototype.request_config(param, function (data) {
              var proxyForm = bt_tools.form({
                el: '.proxy-form',
                formLabelWidth: '130px',
                data: $.extend(data, {
                  websocket: data.websocket?.websocket_status,
                  proxy_connect_timeout: data.timeout?.proxy_connect_timeout,
                  proxy_send_timeout: data.timeout?.proxy_send_timeout,
                  proxy_read_timeout: data.timeout?.proxy_read_timeout,
                }),
                form: [
                  {
                    label: '代理目录',
                    group: {
                      type: 'text',
                      name: 'proxy_path',
                      disabled: true,
                      width: '400px'
                    }
                  },
                  {
                    label: '目标',
                    group: {
                      type: 'select',
                      name: 'proxy_type',
                      width: '160px',
                      list: [
                        {
                          title: 'URL地址',
                          value: 'http'
                        },
                        // {
                        //   title: 'unix地址',
                        //   value: 'unix'
                        // }
                      ],
                    }
                  },
                  {
                    label: '',
                    must: '*',
                    group: {
                      type: 'text',
                      name: 'proxy_pass',
                      placeholder: '请输入目标地址',
                      width: '400px',
                      input: function (formData, element, _that) {
                        var todomain_config = _that.config.form[3].group
                        var value = formData.proxy_pass.replace(/^http[s]?:\/\//, '')
                        value = value.replace(/(:|\?|\/|\\)(.*)$/, '')
                        todomain_config.value = formData.proxy_type === 'unix' ? '$http_host' : value
                        $('[name=proxy_host]').val(value)
                      }
                    }
                  },
                  {
                    label: '发送域名(host)',
                    must: '*',
                    group: {
                      type: 'text',
                      name: 'proxy_host',
                      width: '400px',
                      placeholder: '请输入发送域名',
                      value: '',
                    },
                  },
                  {
                    label: '备注',
                    group: {
                      type: 'text',
                      name: 'remark',
                      width: '400px',
                      placeholder: '请输入备注，可为空',
                      value: '',
                    },
                  },
                  {
                    label: 'websocket支持',
                    group: {
                      type: 'checkbox',
                      name: 'websocket',
                      title: ''
                    },
                  },
                  {
                    label: '连接超时时间',
                    must: '*',
                    group: {
                      class: 'group groupUnit',
                      type: 'number',
                      name: 'proxy_connect_timeout',
                      width: '356px',
                      unit: '秒',
                      value: '',
                    },
                  },
                  {
                    label: '后端请求超时时间',
                    must: '*',
                    group: {
                      class: 'group groupUnit',
                      type: 'number',
                      name: 'proxy_send_timeout',
                      width: '356px',
                      unit: '秒',
                      value: '',
                    },
                  },
                  {
                    label: '代理响应超时时间',
                    must: '*',
                    group: {
                      class: 'group groupUnit',
                      type: 'number',
                      name: 'proxy_read_timeout',
                      width: '356px',
                      unit: '秒',
                      value: '',
                    },
                  },
                  {
                    label: ' ',
                    group: {
                      type: 'button',
                      title: '保存',
                      name: 'save_config',
                      event: function (formData, element, $that) {
                        if (!formData.proxy_pass) return bt_tools.msg({msg: '目标URL不能为空', status: false})
                        if (!formData.proxy_host) return bt_tools.msg({msg: '发送域名不能为空', status: false})
                        if (!formData.proxy_connect_timeout) return bt_tools.msg({msg: '连接超时时间不能为空', status: false})
                        if (!formData.proxy_send_timeout) return bt_tools.msg({msg: '后端请求超时时间不能为空', status: false})
                        if (!formData.proxy_read_timeout) return bt_tools.msg({msg: '代理响应超时时间不能为空', status: false})
                        formData.websocket = formData.websocket ? 1 : 0
                        formData.site_name = web.name
                        formData.proxy_path = row.proxy_path
                        bt_tools.send({url: '/project/proxy/set_url_proxy',data: { data: JSON.stringify(formData) }},function(res) {
                          bt_tools.msg(res)
                          that.$refresh_table_list()
                        }, '设置反向代理')
                      }
                    }
                  }
                ]
              })
            })
          }
        },
        {
          title: '自定义配置',
          callback: function (robj) {
            robj.html('<div class="custom-config-form pd20"></div>')
            CreateWebsiteModel.prototype.request_config(param, function (data) {
              bt_tools.form({
                el: '.custom-config-form',
                formLabelWidth: '110px',
                data,
                form: [
                  {
                    label: '需要插入的配置',
                    group: {
                      type: 'textarea',
                      name: 'custom_conf',
                      placeholder: '一行一条配置，请以;结尾，例如：\nproxy_set_header Cookie "cookie_name=cookie_value";\nallow 192.168.1.0/24;\naccess_log /www/wwwlogs/xxx.log;',
                      style: { width: '440px', height: '120px', 'line-height': '22px' },
                    },
                  },
                  {
                    label: ' ',
                    group: {
                      type: 'button',
                      title: '保存',
                      name: 'save_config',
                      event: function (formData, element, $that) {
                        formData.site_name = web.name
                        formData.proxy_path = row.proxy_path
                        bt_tools.send({url: '/project/proxy/set_url_custom_conf',data: { data: JSON.stringify(formData) }},function(res) {
                          bt_tools.msg(res)
                          that.$refresh_table_list()
                        }, '设置自定义配置')
                      }
                    }
                  },
                  {
                    formLabelWidth: '0px',
                    group: {
                      type: 'help',
                      list: [
                        '注意：一行一条配置，请以;结尾',
                        '案例：<br>\
                        重定向请求：return 301 /new-page;<br>\
                        重写URL：rewrite ^/blog/(.*)$ /$1 break;<br>\
                        文件上传限制：client_max_body_size 10M;<br>\
                        处理特定http方法：<br>\
                        limit_except POST {<br>\
                            allow 192.168.1.0/24;<br>\
                            deny all;<br>\
                        }<br>\
                        限制请求速率：limit_rate 100k;',
                        '保存配置前请核对配置是否正确，错误的配置可能会导致反向代理无法正常访问'
                      ]
                    }
                  }
                ]
              })
            })
          }
        },
        {
          title: '内容替换',
          callback: function (robj) {
            robj.html('<div class="content-replace-table"></div>' + bt.render_help(['规则解释如下', 'g：替换所有匹配到的关键字', 'i：不区分大小写', 'o：只替换匹配到的第一个', 'r：使用正则表达式']))
            bt_tools.table({
              el: '.content-replace-table',
              url: '/project/proxy/get_proxy_list',
              param,
              height: '330',
              dataFilter: function (res) {
                return {
                  data: res.data.sub_filter.sub_filter_str
                }
              },
              column: [
                {
                  fid: 'oldstr',
                  title: '原关键词',
                  width: 294,
                },
                {
                  fid: 'newstr',
                  title: '替换词',
                  width: 294,
                },
                {
                  fid: 'sub_type',
                  title: '规则',
                  width: 50,
                  template: function (_row) {
                    return '<span class="rules-tips" data-oldstr="'+ _row.oldstr +'" data-newstr="'+ _row.newstr +'">'+ _row.sub_type +'</span>'
                  }
                },
                {
                  title: '操作',
                  type: 'group',
                  align: 'right',
                  width: 80,
                  group: [
                    {
                      title: '删除',
                      event: function (_row, index, ev, key, _that) {
                        bt_tools.send({url: '/project/proxy/del_sub_filter',data: {
                          data: JSON.stringify({
                            site_name: web.name,
                            proxy_path: row.proxy_path,
                            oldstr: _row.oldstr,
                            newstr: _row.newstr
                          })
                        }}, function (res) {
                          bt_tools.msg(res)
                          if (res.status) {
                            _that.$refresh_table_list()
                          }
                        })
                      }
                    }
                  ]
                }
              ],
              tootls: [
                {
                  // 按钮组
                  type: 'group',
                  positon: ['left', 'top'],
                  list: [
                    {
                      title: '添加内容替换',
                      active: true,
                      event: function (ev, _that) {
                        bt_tools.open({
                          title: '添加内容替换【'+ row.proxy_path +'】',
                          area: '600px',
                          btn: ['提交', '取消'],
                          content: {
                            class: 'pd20',
                            formLabelWidth: '120px',
                            form: [
                              {
                                label: '原关键词',
                                must: '*',
                                group: {
                                  type: 'text',
                                  name: 'oldstr',
                                  width: '400px',
                                  placeholder: '请输入要被替换的内容，如：http://www.bt.cn',
                                  input: function (formData, element, $that) {
                                    replace_event(formData, element, $that)
                                  }
                                }
                              },
                              {
                                label: '替换词',
                                group: {
                                  type: 'text',
                                  name: 'newstr',
                                  width: '400px',
                                  placeholder: '新的内容，如：https://www.bt.cn',
                                  input: function (formData, element, $that) {
                                    replace_event(formData, element, $that)
                                  }
                                }
                              },
                              {
                                label: ' ',
                                group: [
                                  {
                                    type: 'checkbox',
                                    title: '不区分大小写（i）',
                                    name: 'i',
                                    event: function (formData, element, $that) {
                                      replace_event(formData, element, $that)
                                    }
                                  },
                                  {
                                    type: 'checkbox',
                                    title: '只替换第一个（o）',
                                    style: {'margin-left': '20px'},
                                    name: 'o',
                                    event: function (formData, element, $that) {
                                      replace_event(formData, element, $that)
                                    }
                                  },
                                  {
                                    type: 'checkbox',
                                    title: '正则表达式（r）',
                                    style: {'margin-left': '20px'},
                                    name: 'r',
                                    event: function (formData, element, $that) {
                                      replace_event(formData, element, $that)
                                    }
                                  },
                                ]
                              },
                              {
                                label: ' ',
                                group: {
                                  type: 'other',
                                  boxcontent: "默认效果：将全部'http://www.bt.cn'替换为'https://www.bt.cn'"
                                }
                              }
                            ]
                          },
                          yes: function (formData, indexs) {
                            if (!formData.oldstr) {
                              bt.msg({ status: false, msg: '原关键词不能为空' });
                              return
                            }
                            var sub_type = []
                            for (var key in formData) {
                              if (['i', 'o', 'r'].includes(key) && formData[key] === true) {
                                sub_type.push(key)
                              }
                            }
                           
                            bt_tools.send({url: '/project/proxy/add_sub_filter', data: {
                              data: JSON.stringify({
                                site_name: web.name,
                                oldstr: formData.oldstr,
                                newstr: formData.newstr,
                                proxy_path: row.proxy_path,
                                sub_type: sub_type.length ? sub_type.join('') : 'g',
                              })
                            }}, function (res) {
                              bt_tools.msg(res)
                              if (res.status) {
                                _that.$refresh_table_list()
                                layer.close(indexs)
                              }
                            }, '添加内容替换')
                          } 
                        })
                      },
                    },
                  ],
                },
              ],
              success: function () {
                $('.rules-tips').hover(function () {
                  var oldstr = $(this).data('oldstr'), newstr = $(this).data('newstr'), type = $(this).text()
                  var tips = replace_event({
                    oldstr,
                    newstr,
                    i: type.includes('i'),
                    o: type.includes('o'),
                    r: type.includes('r'),
                  })
                  layer.tips(tips.replace('默认', ''), $(this), { tips: [1, '#666'], time: 0, area: 'auto' });
                },function () {
                  layer.closeAll('tips')
                })
              }
            })

            // 内容替换事件
            function replace_event (formData, element, $that) {
              var tips = ''
              var selected = []
              for (var key in formData) {
                if (['i', 'o', 'r'].includes(key) && formData[key] === true) {
                  selected.push(key)
                }
              }
              if (!selected.length) {
                tips = '默认'
              }
              tips += '效果：将'+ (formData.o ? '' : '全部') + formData.oldstr +'替换为'+ formData.newstr
              if (selected.length) {
                tips += '，匹配时'
              }
              for (var i = 0; i < selected.length; i++) {
                if (selected[i] === 'i') tips += '不区分大小写'
                if (selected[i] === 'o') tips += '只替换第一个'
                if (selected[i] === 'r') tips += '使用正则表达式'
                if (i !== selected.length - 1) {
                  if (selected.length === 3 && i === 0) tips += '、'
                  else tips += '并且'
                }
              }
              if ($that) {
                $that.config.form[3].group.boxcontent = tips
                $that.$replace_render_content(3)
              }
              return tips
            }
          }
        },
        {
          title: '缓存',
          callback: function (robj) {
            CreateWebsiteModel.prototype.request_config(param, function (data) {
              CreateWebsiteModel.prototype.cache_config(data, robj, web, that, row)
            })
          }
        },
        {
          title: '内容压缩',
          callback: function (robj) {
            CreateWebsiteModel.prototype.request_config(param, function (data) {
              CreateWebsiteModel.prototype.content_compress(data, robj, web, that, row)
            })
          }
        },
        {
          title: 'IP黑名单',
          callback: function (robj) {
            CreateWebsiteModel.prototype.ip_list(robj, web, that, 'black', row)
          }
        },
        {
          title: 'IP白名单',
          callback: function (robj) {
            CreateWebsiteModel.prototype.ip_list(robj, web, that, 'white', row)
          }
        }
      ]
      bt.render_tab('url-setting-box', _tab);
      $('#url-setting-box span:eq(0)').click();
    }
  })
}


/**
 * @description 缓存
 * @param {*} robj 
 * @param {*} web 
 * @param {*} that 
 * @param {*} row 存在 则为url反代 设置 缓存 否则为 全局配置缓存
 */
CreateWebsiteModel.prototype.cache_config = function (data, robj, web, that, row) {
  robj.html('<div class="pd20"><div class="cache-form"></div>' + 
  (row ? '' : '<hr><button class="btn btn-default btn-sm clear-cache">清理缓存</button>') +  
  bt.render_help(['缓存是一种用于加速网站性能和提高用户体验的技术', '开启后资源会被缓存，如果影响网站访问请关闭', '缓存键由主机名、URI 和请求参数组成','默认忽略的响应头有：Set-Cookie|Cache-Control|expires|X-Accel-Expires', '默认缓存的静态资源有：css|js|jpg|jpeg|gif|png|webp|woff|eot|ttf|svg|ico|css.map|js.map']) + '</div>')
  var time = '',
    unit = 'm'
  if (data.proxy_cache.expires.length > 1) {
    time = data.proxy_cache.expires.slice(0, -1)
    unit = data.proxy_cache.expires.slice(-1)
  }
  var cacheForm = bt_tools.form({
    el: '.cache-form',
    data: {
      time: time,
      unit: unit
    },
    form: [
      {
        label: '缓存开关',
        group: {
          type: 'other',
          boxcontent: '<div class="inlineBlock mr50" style="margin-top: 5px;vertical-align: -6px;">\
            <input class="btswitch btswitch-ios" id="cache_status" type="checkbox" name="cache_status" '+ (data.proxy_cache.cache_status ? 'checked' : '') +'>\
            <label class="btswitch-btn" for="cache_status" style="margin-bottom: 0;"></label>\
          </div>'
        }
      },
      {
        label: '缓存时间',
        display: data.proxy_cache.cache_status,
        group: [
          {
            type: 'number',
            name: 'time',
            width: '160px',
            min: 1,
          },
          {
            type: 'select',
            name: 'unit',
            width: '80px',
            list: [
              {
                title: '分钟',
                value: 'm'
              },
              {
                title: '小时',
                value: 'h'
              },
              {
                title: '天',
                value: 'd'
              }
            ]
          },
        ]
      },
      {
        label: ' ',
        display: data.proxy_cache.cache_status,
        group: {
          type: 'button',
          name: 'save-btn',
          title: '保存',
          event: function (formData, element, $that) {
            save_config($.extend(formData, { cache_status: 1 }))
          }
        }
      }
    ]
  })
  $('[name=cache_status]').change(function () {
    var checked = $(this).prop('checked')
    cacheForm.config.form[1].display = checked
    cacheForm.config.form[2].display = checked
    cacheForm.$replace_render_content(1)
    cacheForm.$replace_render_content(2)
    var formData = cacheForm.$get_form_value()
    save_config($.extend(formData, { cache_status: checked ? 1 : 0 }))
  })

  $('.clear-cache').unbind('click').click(function () {
    bt.simple_confirm({title: '清理缓存【'+ web.name +'】',msg: '清理后包含所有URL的及站点的缓存都会被清空,是否继续？'}, function () {
      bt_tools.send({url: '/project/proxy/clear_cache', data: { data: JSON.stringify({site_name: web.name}) }}, function (res) {
        bt_tools.msg(res)
      }, '清理缓存')
    })
  })

  function save_config(formData) {
    formData = $.extend({
      time: time,
      unit: unit
    }, formData)
    if (formData.cache_status && (!formData.time || !Number.isInteger(parseFloat(formData.time) || formData.time < 1))) return bt.msg({ status: false, msg: '缓存时间必须大于0的整数' });
    var params = {
      site_name: web.name,
      cache_status: formData.cache_status,
      expires: formData.time + formData.unit
    }
    if (row) params.proxy_path = row.proxy_path
    bt_tools.send({url: row ? '/project/proxy/set_url_cache' : '/project/proxy/set_global_cache', data: { data: JSON.stringify(params) }}, function (res) {
      bt_tools.msg(res)
      // if (res.status) 
    }, '设置缓存')
  }
}

/**
 * @description 内容压缩
 * @param {*} robj 
 * @param {*} web 
 * @param {*} that 
 * @param {*} row 存在 则为url反代 设置 内容压缩 否则为 全局配置内容压缩
 */
CreateWebsiteModel.prototype.content_compress = function (data, robj, web, that, row) {
  robj.html('<div class="pd20"><div class="compress-form"></div>' + bt.render_help(['用于对 HTTP 响应的内容进行压缩，以减少数据传输量，提高网站性能和加载速度', '压缩级别1-9，例如：1为压缩速度最快，但压缩率较低；9为压缩速度最慢，但压缩率最高，建议默认', '如果开启gzip后影响网站正常访问，请关闭此功能 和请求参数组成']) + '</div>')
  var gzip = data.gzip
  gzip.minLength = ''
  gzip.unit = 'm'
  if (gzip.gzip_min_length && gzip.gzip_min_length.length > 1) {
    gzip.minLength = data.gzip.gzip_min_length.slice(0, -1)
    gzip.unit = gzip.gzip_min_length.slice(-1)
  }
  var compressForm = bt_tools.form({
    el: '.compress-form',
    data: gzip,
    form: [
      {
        label: '内容压缩',
        group: {
          type: 'other',
          boxcontent: '<div class="inlineBlock mr50" style="margin-top: 5px;vertical-align: -6px;">\
            <input class="btswitch btswitch-ios" id="gzip_status" type="checkbox" name="gzip_status" '+ (gzip.gzip_status ? 'checked' : '') +'>\
            <label class="btswitch-btn" for="gzip_status" style="margin-bottom: 0;"></label>\
          </div>'
        }
      },
      {
        label: '压缩类型',
        display: gzip.gzip_status,
        must: '*',
        group: {
          type: 'textarea',
          name: 'gzip_types',
          style: { width: '420px', height: '120px', 'line-height': '22px', resize: 'none' },
        }
      },
      {
        label: '压缩级别',
        display: gzip.gzip_status,
        group: {
          type: 'select',
          name: 'gzip_comp_level',
          width: '420px',
          list: [
            { title: '1', value: '1' },
            { title: '2', value: '2' },
            { title: '3', value: '3' },
            { title: '4', value: '4' },
            { title: '5', value: '5' },
            { title: '6', value: '6' },
            { title: '7', value: '7' },
            { title: '8', value: '8' },
            { title: '9', value: '9' },
          ]
        }
      },
      {
        label: '压缩最小长度',
        display: gzip.gzip_status,
        group: [
          {
            type: 'number',
            name: 'minLength',
            width: '160px',
            min: 1,
          },
          {
            type: 'select',
            name: 'unit',
            width: '80px',
            list: [
              {
                title: 'k',
                value: 'k'
              },
              {
                title: 'm',
                value: 'm'
              },
            ]
          },
        ]
      },
      {
        label: ' ',
        display: gzip.gzip_status,
        group: {
          type: 'button',
          name: 'save-btn',
          title: '保存',
          event: function (formData, element, $that) {
            save_config($.extend(formData, {
              gzip_status: 1
            }))
          }
        }
      }
    ]
  })
  $('[name=gzip_status]').change(function () {
    var checked = $(this).prop('checked')
    for (let i = 1; i < 5; i++) {
      compressForm.config.form[i].display = checked
      compressForm.$replace_render_content(i)
    }
    var formData = compressForm.$get_form_value()
    save_config($.extend(formData, {
      gzip_status: checked ? 1 : 0
    }))
  })

  function save_config(formData) {
    formData = $.extend(gzip, formData)
    if (formData.gzip_status && !formData.gzip_types) return bt.msg({ status: false, msg: '压缩类型不能为空' });
    if (formData.gzip_status && (!formData.minLength || !Number.isInteger(parseFloat(formData.minLength) || formData.minLength < 1))) return bt.msg({ status: false, msg: '缓存时间必须大于0的整数' });
    var params = {
      site_name: web.name,
      gzip_status: formData.gzip_status,
      gzip_comp_level: formData.gzip_comp_level,
      gzip_min_length: formData.minLength + formData.unit,
      gzip_types: formData.gzip_types
    }
    if (row) params.proxy_path = row.proxy_path
    bt_tools.send({url: row ? '/project/proxy/set_url_gzip' : '/project/proxy/set_global_gzip', data: { data: JSON.stringify(params) }}, function (res) {
      bt_tools.msg(res)
      // if (res.status) 
    }, '设置内容压缩')
  }
}

/**
 * @description ip 黑白名单
 * @param {*} robj 
 * @param {*} web 
 * @param {*} that 
 * @param {*} type 类型 black white
 * @param {*} row 存在 则为url反代 设置 黑白名单 否则为 全局配置黑白名单
 */
CreateWebsiteModel.prototype.ip_list = function (robj, web, that, type, row) {
  robj.html('<div class="ip-list-table"></div>' + (type === 'white' ? bt.render_help(['注意：设置IP白名单后会默认禁止除白名单以外的所有IP访问']) : ''))
  var title = 'IP' + (type === 'black' ? '黑' : '白') + '名单'
  var param = {
    site_name: web.name,
  }
  if (row) param.proxy_path = row.proxy_path
  var ipListTable = bt_tools.table({
    el: '.ip-list-table',
    url: row ? '/project/proxy/get_proxy_list' : '/project/proxy/get_global_conf',
    param: {
      data: JSON.stringify(param)
    },
    dataVerify:false,
    height: '400',
    dataFilter: function (res) {
      var data = [], list = res?.data?.ip_limit['ip_'+ type] || []
      for (var i = 0; i < list.length; i++) {
        data.push({ip: list[i]})
      }
      return {
        data: data
      }
    },
    column: [
      { type: 'checkbox', width: 20 },
      {
        fid: 'ip',
        title: 'IP',
      },
      {
        title: '操作',
        type: 'group',
        align: 'right',
        group: [
          {
            title: '删除',
            event: function (_row, index, ev, key, _that) {
              var params = {
                site_name: web.name,
                ip: _row.ip,
                ip_type: type
              }
              if (row) params.proxy_path = row.proxy_path
              bt_tools.send({url: row ? '/project/proxy/del_url_ip_limit' : '/project/proxy/del_ip_limit',data: { data: JSON.stringify(params) }}, function (res) {
                bt_tools.msg(res)
                if (res.status) {
                  _that.$refresh_table_list()
                }
              })
            }
          }
        ]
      }
    ],
    tootls: [
      {
        // 按钮组
        type: 'group',
        positon: ['left', 'top'],
        list: [
          {
            title: '添加'+ title,
            active: true,
            event: function (ev, _that) {
              bt_tools.open({
                title: '添加'+ title + ( row ? '【'+ row.proxy_path +'】' : ''),
                area: '400px',
                btn: ['确认', '取消'],
                content: {
                  class: 'pd20',
                  form: [
                    {
                      label: 'IP',
                      must: '*',
                      formLabelWidth: '60px',
                      group: {
                        type: 'textarea',
                        name: 'ip',
                        placeholder: '请输入IP地址',
                        style: { width: '280px', height: '120px', 'line-height': '22px', resize: 'none' },
                      }
                    },
                    {
                      group: {
                        type: 'help',
                        list: ['一行一条配置，多个IP请换行']
                      }
                    }
                  ]
                },
                yes: function (formData, indexs) {
                  if (!formData.ip) {
                    bt.msg({ status: false, msg: 'IP不能为空' });
                    return
                  }
                  var params = {
                    site_name: web.name,
                    ip_type: type,
                    ips: formData.ip,
                  }
                  if (row) params.proxy_path = row.proxy_path
                  bt_tools.send({url: row ? '/project/proxy/add_url_ip_limit' : '/project/proxy/add_ip_limit', data: { data: JSON.stringify(params) }}, function (res) {
                    bt_tools.msg(res)
                    if (res.status) {
                      _that.$refresh_table_list()
                      layer.close(indexs)
                    }
                  }, '添加'+ title)
                } 
              })
            },
          },
        ],
      },
      {
        // 批量操作
        type: 'batch', //batch_btn
        positon: ['left', 'bottom'],
        placeholder: '请选择批量操作',
        buttonValue: '批量操作',
        disabledSelectValue: '请选择需要批量操作的站点!',
        selectList: [
          {
            title: '删除IP',
            url: row ? '/project/proxy/del_url_ip_limit' : '/project/proxy/del_ip_limit',
            load: true,
            param: function (_row) {
              var params = {
                site_name: web.name,
                ip: _row.ip,
                ip_type: type,
              }
              if (row) params.proxy_path = row.proxy_path
              return {
                data: JSON.stringify(params)
              }
            },
            refresh: true,
            callback: function (that) {
              bt.simple_confirm({title: '批量删除IP', msg: '您正在删除选中的IP，继续吗？'}, function () {
                that.start_batch({}, function (list) {
                  var html = '';
                  for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    html +=
                      '<tr><td><span>' +
                      item.ip +
                      '</span></td><td align="right"><div class="break-all" style="width: 150px;"><span style="color:' +
                      (item.requests.status ? '#20a53a' : 'red') +
                      '">' +
                      (item.requests.msg) +
                      '</span></div></td></tr>';
                  }
                  ipListTable.$batch_success_table({ title: '批量删除IP', th: 'IP', html: html });
                  ipListTable.$refresh_table_list(true);
                });
              });
            },
          },
        ]
      }
    ],
  })
}

/**
 * @description 配置文件
 * @param {*} web 
 */
CreateWebsiteModel.prototype.config_files = function (web) {
  $('#webedit-con').append('<div id="config-files-box" class="tab-nav"></div><div class="tab-con" style="padding:10px 0px;"></div>');

  var _tab = [
    {
      title: '主配置文件',
      callback: function (robj) {
        robj.html(render_html('site_conf'))
        get_logs({el: 'site_conf'})
      }
    },
    {
      title: '自定义配置文件',
      callback: function (robj) {
        robj.html(render_html('custom_conf'))
        bt_tools.form({
          el: '.select-type',
          formLabelWidth: '94px',
          form: [
            {
              label: '选择配置块：',
              group: {
                type: 'select',
                name: 'fileType',
                width: '160px',
                list: [
                  { title: 'server块', value: 'server_block' },
                  { title: 'HTTP块', value: 'http_block' },
                ],
                change: function (formData, element, _that) {
                  get_logs({el: 'custom_conf', key: formData.fileType})
                }
              }
            }
          ]
        })
        get_logs({el: 'custom_conf', key: 'server_block'})
      }
    }
  ]

  bt.render_tab('config-files-box', _tab);
  $('#config-files-box span:eq(0)').click();

  // 渲染html
  function render_html(el) {
    return (el === 'site_conf' ? '<p style="color: #666; margin-bottom: 7px">主配置文件不允许修改，如需自定义配置请到上方自定义配置文件中操作</p>' : '<div class="select-type"></div>') + 
    '<div class="bt-input-text ace_config_editor_scroll" style="height: '+ (el === 'site_conf' ? '520' : '440') +'px; line-height:18px;" id="'+ el +'"></div>' + 
    (el === 'site_conf' ? '' : '<button class="'+ el +'_btn btn btn-success btn-sm mr10" style="margin-top:10px;">保存</button>') +
    '<button class="copy_btn btn btn-default btn-sm" style="margin-top:10px;" data-clipboard-text="">复制</button>' +
    (el === 'site_conf' ? '' : bt.render_help([
      '保存前请检查输入的配置文件是否正确，错误的配置可能会导致网站访问异常',
       '如果您对此配置不熟悉，请勿添加自定义配置', 
      'server块的nginx官方配置文档：<a class="btlink" target="_blank" href="https://nginx.org/en/docs/http/ngx_http_core_module.html#server">点击跳转</a>']))
  }

  // 获取指定配置文件
  function get_logs(obj) {
    bt_tools.send({url: '/project/proxy/get_config', data: { data: JSON.stringify({site_name: web.name}) }},function (res) {
      var msg = res?.data[obj?.key || obj.el] || ''
      var logs_obj = {
        el: obj.el,
        content: msg,
        readOnly: obj.el === 'site_conf',
      }
      if (!logs_obj.readOnly) {
        logs_obj.saveCallback = function (val) {
        	$('.'+ obj.el + '_btn').click()
        }
      }
      var aEditor = bt.aceEditor(logs_obj)
      $('.copy_btn').attr('data-clipboard-text', aEditor.ACE.getValue());
      $('.'+obj.el + '_btn').unbind('click').click(function () {
        bt_tools.send({url: '/project/proxy/save_config', data: { 
          data: JSON.stringify({
            site_name: web.name,
            conf_type: obj.key,
            body: aEditor.ACE.getValue()
          }) 
        }}, function(res) {
          bt.msg(res)
        })
      })
      var clipboard = new ClipboardJS('.copy_btn');
      clipboard.on('success', function (e) {
        bt.msg({status: true,msg: '复制成功！'});
        e.clearSelection();
      });
      clipboard.on('error', function (e) {
        bt.msg({status: false,msg: '复制失败，请手动复制地址'});
      });
    }, {load: '获取配置文件' ,verify: false})
  }
}

/**
 * @description 全局配置请求
 */
CreateWebsiteModel.prototype.request_global = function (data, callabck) {
  bt_tools.send({url: '/project/proxy/get_global_conf', data}, function (res) {
    if (callabck) callabck(res.data)
  }, '获取数据')
}

/**
 * @description 全局配置
 */
CreateWebsiteModel.prototype.global_config = function (web) {
  var param = {
    data: JSON.stringify({
      site_name: web.name
    })
  }
  $('#webedit-con').append('<div id="global-config-box" class="tab-nav"></div><div class="tab-con" style="padding:10px 0px;"></div>');
  var _tab = [{
      title: '缓存',
      callback: function (robj) {
        CreateWebsiteModel.prototype.request_global(param, function (data) {
          CreateWebsiteModel.prototype.cache_config(data, robj, web, site.model_table)
        })
      },
    },
    {
      title: '内容压缩',
      callback: function (robj) {
        CreateWebsiteModel.prototype.request_global(param, function (data) {
          CreateWebsiteModel.prototype.content_compress(data, robj, web, site.model_table)
        })
      },
    },
    {
      title: 'IP黑名单',
      callback: function (robj) {
        CreateWebsiteModel.prototype.ip_list(robj, web, site.model_table, 'black')
      },
    },
    {
      title: 'IP白名单',
      callback: function (robj) {
        CreateWebsiteModel.prototype.ip_list(robj, web, site.model_table, 'white')
      },
    },
    // {
    //   title: 'http认证',
    //   callback: function (robj) {
    //     robj.html('<div class="http-auth-table"></div>')
    //     bt_tools.table({
    //       el: '.http-auth-table',
    //       url: '/project/proxy/get_global_conf',
    //       param,
    //       dataVerify:false,
    //       height: '400',
    //       dataFilter: function (res) {
    //         return {
    //           data: res?.data?.basic_auth || []
    //         }
    //       },
    //       column: [
    //         {
    //           fid: 'auth_name',
    //           title: '名称'
    //         },
    //         {
    //           fid: 'auth_path',
    //           title: '路径'
    //         },
    //         {
    //           title: '操作',
    //           align: 'right',
    //           type: 'group',
    //           group: [
    //             {
    //               title: '编辑',
    //               event: function (_row, index, ev, key, _that) {
    //                 _that.edit_auth(_row, _that)
    //               }
    //             },
    //             {
    //               title: '删除',
    //               event: function (_row, index, ev, key, _that) {
    //                 bt.simple_confirm({title: '删除http认证【'+ _row.auth_name +'】', msg: '删除http认证【'+ _row.auth_name +'】，是否继续操作？'}, function () {
    //                   bt_tools.send({url: '/project/proxy/del_dir_auth', data: {
    //                     data: JSON.stringify({
    //                       site_name: web.name,
    //                       auth_path: _row.auth_path,
    //                       name: _row.auth_name
    //                     })
    //                   }}, function (res) {
    //                     bt_tools.msg(res)
    //                     if (res.status) _that.$refresh_table_list()
    //                   }, '删除http认证')
    //                 })
    //               }
    //             }
    //           ]
    //         }
    //       ],
    //       tootls: [
    //         {
    //           // 按钮组
    //           type: 'group',
    //           positon: ['left', 'top'],
    //           list: [
    //             {
    //               title: '添加',
    //               active: true,
    //               event: function (ev, _that) {
    //                 _that.edit_auth(false, _that)
    //               },
    //             },
    //           ],
    //         },
    //       ],
    //       methods: {
    //         edit_auth: function (row, _that) {
    //           bt_tools.open({
    //             title: (row ? '编辑' : '添加') + 'http认证',
    //             area: '480px',
    //             btn: ['确认', '取消'],
    //             content: {
    //               class: 'pd20',
    //               data: row ? {
    //                 name: row.auth_name,
    //                 auth_path: row.auth_path
    //               } : {
    //                 name: bt.get_random(5)
    //               },
    //               form: [
    //                 {
    //                   label: '名称',
    //                   must: '*',
    //                   group: {
    //                     type: 'text',
    //                     name: 'name',
    //                     placeholder: '请输入名称',
    //                     width: '280px'
    //                   }
    //                 },
    //                 {
    //                   label: '路径',
    //                   must: '*',
    //                   group: {
    //                     type: 'text',
    //                     name: 'auth_path',
    //                     placeholder: '请输入路径，例如：/web',
    //                     width: '280px'
    //                   }
    //                 },
    //                 {
    //                   label: '用户名',
    //                   must: '*',
    //                   group: {
    //                     type: 'text',
    //                     name: 'username',
    //                     placeholder: '请输入用户名',
    //                     width: '280px'
    //                   }
    //                 },
    //                 {
    //                   label: '密码',
    //                   must: '*',
    //                   group: {
    //                     type: 'text',
    //                     name: 'password',
    //                     placeholder: '请输入密码',
    //                     width: '280px'
    //                   }
    //                 },
    //                 {
    //                   group: {
    //                     type: 'help',
    //                     list: ['例如我设置了加密访问/test/,那我访问http://aaa.com/test/时就要输入账号密码才能访问']
    //                   }
    //                 }
    //               ]
    //             },
    //             yes: function (formData, indexs) {
    //               if (!formData.name) return bt.msg({status: false, msg: '名称不能为空'})
    //               if (!formData.auth_path) return bt.msg({status: false, msg: '路径不能为空'})
    //               if (!formData.username) return bt.msg({status: false, msg: '用户名不能为空'})
    //               if (!formData.password) return bt.msg({status: false, msg: '密码不能为空'})
    //               formData.site_name = web.name
    //               bt_tools.send({url: '/project/proxy/'+ (row ? 'set_dir_auth' : 'add_dir_auth'), data: { data: JSON.stringify(formData) }}, function (res) {
    //                 bt_tools.msg(res)
    //                 if (res.status) {
    //                   layer.close(indexs)
    //                   _that.$refresh_table_list()
    //                 }
    //               }, (row ? '编辑' : '添加') +'http认证')
    //             }
    //           })
    //         }
    //       }
    //     })
    //   },
    // },
    {
      title: '日志',
      callback: function (robj) {
        robj.html('<div class="logs-form"></div>'+ bt.render_help(['指定目录可选择自定义的日志存储目录，请注意此目录必须www用户可写', '发送到远程服务器设置之后本地不会保存日志内容，填写前请确保日志接收端可正常访问']))
        CreateWebsiteModel.prototype.request_global(param, function (data) {
          bt_tools.form({
            el: '.logs-form',
            class: 'pd20',
            data: data.proxy_log,
            form: [
              {
                label: '日志',
                group: {
                  type: 'select',
                  name: 'log_type',
                  width: '240px',
                  list: [
                    {
                      title: '默认',
                      value: 'default'
                    },
                    {
                      title: '不记录日志',
                      value: 'off'
                    },
                    {
                      title: '指定目录',
                      value: 'file'
                    },
                    {
                      title: '发送到远程服务器',
                      value: 'rsyslog'
                    },
                  ],
                  change: function (formData, element, _that) {
                    _that.config.form[1].display = formData.log_type === 'file'
                    _that.config.form[2].display = formData.log_type === 'rsyslog'
                    _that.$replace_render_content(1)
                    _that.$replace_render_content(2)
                  }
                }
              },
              {
                label: '访问日志',
                display: data.proxy_log.log_type === 'file',
                group: {
                  type: 'text',
                  name: 'log_path',
                  width: '350px',
                  placeholder: '请选择或输入目录，例如：C:/BtSoft/wwwlogs',
                  icon: {
                    type: 'glyphicon-folder-open',
                    select: 'dir',
                    event: function (ev) {},
                  }
                }
              },
              {
                label: '接收地址',
                display: data.proxy_log.log_type === 'rsyslog',
                group: {
                  type: 'text',
                  name: 'rsyslog_host',
                  width: '240px',
                  placeholder: '接收地址，如：202.96.128.86:9204'
                }
              },
              {
                label: ' ',
                group: {
                  type: 'button',
                  title: '保存',
                  name: 'save-btn',
                  event: function (formData, element, _that) {
                    var params = {
                      site_name: web.name,
                      log_type: formData.log_type,
                      log_path: formData.log_type === 'file' ? formData.log_path : formData.log_type === 'rsyslog' ? formData.rsyslog_host : ''
                    }
                    bt_tools.send({url: '/project/proxy/set_global_log',data: { data: JSON.stringify(params) }}, function (res) {
                      bt_tools.msg(res)
                    }, '设置日志配置')
                  }
                }
              }
            ]
          })
        })
      },
    },
    {
      title: 'websocket',
      callback: function (robj) {
        robj.html('<div class="websocker-form pd20"></div>')
        CreateWebsiteModel.prototype.request_global(param, function (data) {
          bt_tools.form({
            el: '.websocker-form',
            formLabelWidth: '120px',
            form: [
              {
                label: 'websocket支持',
                group: {
                  type: 'other',
                  boxcontent: '<div class="inlineBlock mr50" style="margin-top: 5px;vertical-align: -6px;">\
                    <input class="btswitch btswitch-ios" id="websocket_status" type="checkbox" name="websocket_status" '+ (data.websocket.websocket_status ? 'checked' : '') +'>\
                    <label class="btswitch-btn" for="websocket_status" style="margin-bottom: 0;"></label>\
                  </div>'
                }
              },
            ]
          })
          $('[name=websocket_status]').unbind('change').change(function () {
            var checked = $(this).prop('checked')
            bt_tools.send({url: '/project/proxy/set_global_websocket', data: {
              data: JSON.stringify({
                site_name: web.name,
                websocket_status: checked ? 1 : 0
              })
            }}, function (res) {
              bt_tools.msg(res)
            }, '设置websocket支持')
          })
        })
      },
    },
  ];
  bt.render_tab('global-config-box', _tab);
  $('#global-config-box span:eq(0)').click();
}

 /**
 * @description 项目重定向
 */
 CreateWebsiteModel.prototype.reander_project_redirect = function (row,_that) {
	var el = $('#webedit-con');
	el.empty();
	// if (row.project_config.bind_extranet === 0) {
	// 		$('.mask_module').removeClass('hide').find('.node_mask_module_text:eq(1)').hide().prev().show();
	// 		return false;
	// }
  site.edit.set_301(row)
  return
	el.html(
			'<div>\
			<div id="website_redirect"></div>\
			<ul class="help-info-text c7">\
					<li>设置域名重定向后，该域名的404重定向将失效</li>\
			</ul>\
	</div>'
	);
	site.edit.redirect_table = bt_tools.table({
			el: '#website_redirect',
			url: '/project/proxy/get_project_redirect_list',
			param: { sitename: row.name },
			height: 500,
			dataFilter: function (res) {
					$.each(res, function (i, item) {
							if (!item.hasOwnProperty('errorpage')) {
									item.errorpage = 0;
							}
					});
					return { data: res };
			},
			column: [
					// { type: 'checkbox', width: 20 },
					{
							fid: 'sitename',
							title: '被重定向',
							type: 'text',
							width: 120,
							template: function (row, index) {
									var conter = '空';
									if (row.domainorpath == 'path' && row.errorpage !== 1) {
											conter = row.redirectpath || '空';
									} else {
											conter = row.redirectdomain ? row.redirectdomain.join('、') : '空';
									}
									return '<span style="width:100px;" title="' + conter + '">' + conter + '</span>';
							},
					},
					{
							fid: 'method',
							title: '重定向类型',
							type: 'text',
							width: 90,
							template: function (row, index) {
									var str = '';
									if (row.errorpage == 1) {
											str = '错误';
									} else if (row.domainorpath == 'path') {
											str = '路径';
									} else if (row.domainorpath == 'domain') {
											str = '域名';
									}
									return '<span>' + str + '</span>';
							},
					},
					{
							fid: 'path',
							title: '重定向到',
							type: 'text',
							template: function (row, index) {
									var path = row.tourl ? row.tourl : row.topath;
									return (
											'<span title="' +
											path +
											'" style="display: flex;">\
											<span class="size_ellipsis" style="flex: 1; width: 0;">' +
											(row.topath && path == '/' ? '首页' : path) +
											'</span>\
									</span>'
									);
							},
					},
					{
							fid: 'type',
							title: '状态',
							width: 70,
							config: {
									icon: true,
									list: [
											[1, '运行中', 'bt_success', 'glyphicon-play'],
											[0, '已停止', 'bt_danger', 'glyphicon-pause'],
									],
							},
							type: 'status',
							event: function (row, index, ev, key, that) {
									row.type = !row.type ? 1 : 0;
									row.redirectdomain = JSON.stringify(row['redirectdomain']);

									modify_node_refirect(row, function (res) {
											row.redirectdomain = JSON.parse(row['redirectdomain']);
											that.$modify_row_data({ status: row.type });
											bt.msg(res);
									});
							},
					},
					{
							title: '操作',
							width: 150,
							type: 'group',
							align: 'right',
							group: [
									{
											title: '配置文件',
											event: function (row, index, ev, key, that) {
													if(row.type == 0){
															return layer.msg('重定向已暂停',{icon:2})
													}
													var type = '';
													try {
															type = bt.get_cookie('serverType') || serverType;
													} catch (err) {}
													bt.open({
															type: 1,
															area: ['550px', '550px'],
															title: '编辑配置文件[' + row.redirectname + ']',
															closeBtn: 2,
															shift: 0,
															content:
																	'\
													<div class="bt-form pd15">\
															<p style="color: #666; margin-bottom: 7px">提示：Ctrl+F 搜索关键字，Ctrl+S 保存，Ctrl+H 查找替换</p>\
															<div id="redirect_config_con" class="bt-input-text ace_config_editor_scroll" style="height: 350px; line-height: 18px;"></div>\
															<button id="OnlineEditFileBtn" class="btn btn-success btn-sm" style="margin-top:10px;">保存</button>\
															<ul class="help-info-text c7">\
																	<li>此处为该负载均衡的配置文件，若您不了解配置规则,请勿随意修改。</li>\
															</ul>\
													"</div>',
															success: function (layers, indexs) {
																	bt_tools.send(
																			{ url: '/files?action=GetFileBody', data: { path: row.redirect_conf_file } },function (res) {
																					var editor = bt.aceEditor({
																							el: 'redirect_config_con',
																							content: res.data,
																							mode: 'nginx',
                                              path: row.redirect_conf_file,
																							// saveCallback: function (val) {
																							// 	bt.site.save_redirect_config({ path: rdata[1], data: val, encoding: rdata[0].encoding }, function (ret) {
																							// 		if (ret.status) {
																							// 			site.reload(11);
																							// 			layer.close(indexs);
																							// 		}
																							// 		bt.msg(ret);
																							// 	});
																							// },
																					});
																					$('#OnlineEditFileBtn').click(function () {
																							bt.saveEditor(editor);
																					});
																			})
															},
													});
											},
									},
									{
											title: '编辑',
											event: function (crow, index, ev, key, that) {
													node_refirect_301(row.name, row.id, crow);
											},
									},
									{
											title: '删除',
											event: function (row, index, ev, key, that) {
													bt_tools.send({url:'/project/proxy/remove_project_redirect',data:{sitename:row.sitename,redirectname:row.redirectname}},function(rdata){
															bt.msg(rdata);
															if (rdata.status) that.$delete_table_row(index);
													});
											},
									},
							],
					},
			],
			tootls: [
        {
          // 按钮组
          type: 'group',
          positon: ['left', 'top'],
          list: [
            {
              title: '添加重定向',
              active: true,
              event: function (ev) {
                  node_refirect_301(row.name, row.id);
              },
            }
          ],
        },
			],
	});
	function modify_node_refirect(obj,callback){
			bt_tools.send({url:'/project/proxy/modify_project_redirect',data:obj},function(res){
					if(callback) callback(res)
			},'设置重定向')
	}
	function node_refirect_301(sitename, id, nrow){
			var isEdit = !!nrow;
			var form = isEdit
					? nrow
					: {
							redirectname: new Date().valueOf(),
							tourl: 'http://',
							redirectdomain: [],
							redirectpath: '',
							redirecttype: '',
							type: 1,
							domainorpath: 'domain',
							holdpath: 1,
					};
			var helps = [
					'重定向类型：表示访问选择的“域名”或输入的“路径”时将会重定向到指定URL',
					'目标URL：可以填写你需要重定向到的站点，目标URL必须为可正常访问的URL，否则将返回错误',
					'重定向方式：使用301表示永久重定向，使用302表示临时重定向',
					'保留URI参数：表示重定向后访问的URL是否带有子路径或参数如设置访问http://b.com 重定向到http://a.com',
					'保留URI参数：  http://b.com/1.html ---> http://a.com/1.html',
					'不保留URI参数：http://b.com/1.html ---> http://a.com',
			];
			bt_tools.send({url:'/data?action=getData',data:{table:'domain',list:'True',search:id}},function(rdata){
				// bt_tools.send({url:'/project/'+ _that.type +'/GetProjectDomain',data:{data:JSON.stringify({name:sitename})}},function(rdata){
					var flag = true;
					var domain_html = '';
					var select_list = [];
					var table_data = site.edit.redirect_table.data;
					for (var i = 0; i < rdata.length; i++) {
							flag = true;
							for (var j = 0; j < table_data.length; j++) {
									var con1 = site.edit.get_list_equal(table_data[j].redirectdomain, rdata[i].name);
									var con2 = !site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
									if (con1 && con2) {
											flag = false;
											break;
									}
							}
							if (flag) {
									select_list.push(rdata[i]);
									var selected = site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
									domain_html += '<li ' + (selected ? 'class="selected"' : '') + '><a><span class="text">' + rdata[i].name + '</span><span class="glyphicon glyphicon-ok check-mark"></span></a></li>';
							}
					}
					if (!domain_html) {
							domain_html = '<div style="padding: 14px 0; color: #999; text-align: center; font-size: 12px;">暂无域名可选</div>';
					}

					var content =
							'<style>select.bt-input-text { width: 100px; }</style>\
					<div id="form_redirect" class="bt-form-new pd20">\
							<div class="form-inline">\
									<div class="form-item">\
											<div class="form-label">开启重定向</div>\
											<div class="form-value">\
													<input class="btswitch btswitch-ios" id="type" type="checkbox" name="type" checked />\
													<label class="btswitch-btn phpmyadmin-btn" for="type"></label>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label">保留URI参数</div>\
											<div class="form-value">\
													<input class="btswitch btswitch-ios" id="holdpath" type="checkbox" name="holdpath" checked />\
													<label class="btswitch-btn phpmyadmin-btn" for="holdpath"></label>\
											</div>\
									</div>\
							</div>\
							<div class="form-inline">\
									<div class="form-item">\
											<div class="form-label">重定向类型</div>\
											<div class="form-value">\
													<select class="bt-input-text" name="domainorpath">\
															<option value="domain">域名</option>\
															<option value="path">路径</option>\
													</select>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 90px;">重定向方式</div>\
											<div class="form-value">\
													<select class="bt-input-text" style="width: 150px;" name="redirecttype">\
															<option value="301">301（永久重定向）</option>\
															<option value="302">302（临时重定向）</option>\
													</select>\
											</div>\
									</div>\
							</div>\
							<div class="form-inline redirectdomain" style="flex-wrap: nowrap;">\
									<div class="form-item">\
											<div class="form-label">重定向域名</div>\
											<div class="form-value">\
													<div class="btn-group bootstrap-select show-tick redirect_domain" style="width: 200px;">\
															<button type="button" class="btn dropdown-toggle btn-default" style="height: 32px; line-height: 18px; font-size: 12px">\
																	<span class="filter-option pull-left"></span>\
																	<span class="bs-caret"><span class="caret"></span></span>\
															</button>\
															<div class="dropdown-menu open">\
																	<div class="bs-actionsbox">\
																			<div class="btn-group btn-group-sm btn-block">\
																					<button type="button" class="actions-btn bs-select-all btn btn-default">全选</button>\
																					<button type="button" class="actions-btn bs-deselect-all btn btn-default">取消全选</button>\
																			</div>\
																	</div>\
																	<div class="dropdown-menu inner">' +
							domain_html +
							'</div>\
															</div>\
													</div>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 80px;">目标URL</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="tourl" type="text" style="width: 200px;" value="http://" />\
											</div>\
									</div>\
							</div>\
							<div class="form-inline redirectpath" style="display: none; flex-wrap: nowrap;">\
									<div class="form-item">\
											<div class="form-label">重定向路径</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="redirectpath" placeholder="如: http://' +
							sitename +
							' " type="text" style="width: 200px;" />\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 80px;">目标URL</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="tourl1" type="text" style="width: 200px;" value="http://" />\
											</div>\
									</div>\
							</div>\
							<div style="height: 15px;"></div>\
							' +
							bt.render_help(helps) +
							'\
					</div>';
					var redirectdomain = form.redirectdomain;

					var form_redirect = bt.open({
							type: 1,
							skin: 'demo-class',
							area: '650px',
							title: !isEdit ? '添加重定向' : '修改重定向',
							closeBtn: 2,
							shift: 5,
							shadeClose: false,
							btn: ['提交', '取消'],
							content: content,
							success: function () {
									var show_domain_name = function () {
											var text = '';
											if (redirectdomain.length > 0) {
													text = [];
													for (var i = 0; i < redirectdomain.length; i++) {
															text.push(redirectdomain[i]);
													}
													text = text.join(', ');
											} else {
													text = '请选择站点';
											}
											$('.redirect_domain .btn .filter-option').text(text);
									};

									show_domain_name();

									$('.redirect_domain .btn').click(function (e) {
											var $parent = $(this).parent();
											$parent.toggleClass('open');
											$(document).one('click', function () {
													$parent.removeClass('open');
											});
											e.stopPropagation();
									});

									// 单选
									$('.redirect_domain .dropdown-menu li').click(function (e) {
											var $this = $(this);
											var index = $this.index();
											var name = select_list[index].name;
											$this.toggleClass('selected');
											if ($this.hasClass('selected')) {
													redirectdomain.push(name);
											} else {
													var remove_index = -1;
													for (var i = 0; i < redirectdomain.length; i++) {
															if (redirectdomain[i] == name) {
																	remove_index = i;
																	break;
															}
													}
													if (remove_index != -1) {
															redirectdomain.splice(remove_index, 1);
													}
											}
											show_domain_name();
											e.stopPropagation();
									});

									// 全选
									$('.redirect_domain .bs-select-all').click(function () {
											redirectdomain = [];
											for (var i = 0; i < select_list.length; i++) {
													redirectdomain.push(select_list[i].name);
											}
											$('.redirect_domain .dropdown-menu li').addClass('selected');
											show_domain_name();
									});

									// 取消全选
									$('.redirect_domain .bs-deselect-all').click(function () {
											redirectdomain = [];
											$('.redirect_domain .dropdown-menu li').removeClass('selected');
											show_domain_name();
									});

									// 重定向类型
									$('[name="domainorpath"]').change(function () {
											var path = $(this).val();
											$('.redirect_domain .bs-deselect-all').click();
											$('[name="redirectpath"]').val('');
											$('.redirectpath, .redirectdomain').hide();
											switch (path) {
													case 'path':
															$('.redirectpath').show();
															break;
													case 'domain':
															$('.redirectdomain').show();
															break;
											}
									});

									if (isEdit) {
											$('[name="type"]').prop('checked', form.type == 1);
											$('[name="holdpath"]').prop('checked', form.holdpath == 1);
											$('[name="domainorpath"]').val(form.domainorpath);
											$('[name="redirecttype"]').val(form.redirecttype);
											$('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val(form.tourl);
											$('[name="redirectpath"]').val(form.redirectpath);
											$('.redirectpath, .redirectdomain').hide();
											switch (form.domainorpath) {
													case 'path':
															$('.redirectpath').show();
															break;
													case 'domain':
															$('.redirectdomain').show();
															break;
											}
									}

									$('#form_redirect').parent().css('overflow', 'inherit');
							},
							yes: function () {
									form.type = $('[name="type"]').prop('checked') ? 1 : 0;
									form.holdpath = $('[name="holdpath"]').prop('checked') ? 1 : 0;
									form.redirecttype = $('[name="redirecttype"]').val();
									form.domainorpath = $('[name="domainorpath"]').val();
									form.redirectpath = $('[name="redirectpath"]').val();
									form.tourl = $('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val();
									form.redirectdomain = JSON.stringify(redirectdomain);
									bt_tools.send({url:'/project/proxy/'+(isEdit?'modify':'create')+'_project_redirect',data:$.extend(form,{sitename: sitename})},function(rdata){
											if (rdata.status) {
													form_redirect.close();
													site.edit.redirect_table.$refresh_table_list();
											}
											bt.msg(rdata);
									})
							},
					});

			},'获取域名列表')
	}
};

/**
 * @description 绑定请求
 */
CreateWebsiteModel.prototype.bindHttp = function () {
  var that = this;
  for (const item in this.methods) {
    if (Object.hasOwnProperty.call(this.methods, item)) {
      const element = that.methods[item];
      (function (element) {
        CreateWebsiteModel.prototype[item] = function (param, callback) {
          bt_tools.send(
            {
              url: '/project/proxy/' + element[0],
              data: { data: JSON.stringify(param) },
            },
            function (data) {
              if (callback) callback(data);
            },
            { load: element[1] }
          );
        };
      })(element);
    }
  }
};
CreateWebsiteModel.prototype.layerFrom = null;

/**
 * @description 域名管理
 * @param {object} row 项目信息
 */
CreateWebsiteModel.prototype.reanderDomainManageView = function (el, row) {
  var project_domian = null
  var that = this,
    list = [
      {
        class: 'mb0',
        items: [
          {
            name: 'modeldomain',
            width: '480px',
            type: 'textarea',
            placeholder:
              '多个域名，请换行填写，每行一个域名，默认为80端口<br>IP地址格式：192.1638.1.199<br>泛解析添加方法：先添加一个域名 domain.com，后换行添加*.domain.com<br>如另加端口格式为 www.domain.com:88',
          },
          {
            name: 'btn_model_submit_domain',
            text: '添加',
            type: 'button',
            callback: function (sdata) {
              var arrs = sdata.modeldomain.split('\n');
              var domins = [];
              for (var i = 0; i < arrs.length; i++) domins.push(arrs[i]);
              if (domins[0] == '')
                return layer.msg('域名不能为空', { icon: 0 });

              bt_tools.send({url: '/project/proxy/add_domain', data: {
                data: JSON.stringify({
                  id: row.id,
                  site_name: row.name,
                  domains: domins
                })
              }}, function (res) {
                $('[name=modeldomain]').val('');
                $('.placeholder').css('display', 'block');
                site.render_domain_result_table(res)
                project_domian.$refresh_table_list(true);
              }, '添加域名')
            },
          },
        ],
      },
    ];
  var _form_data = bt.render_form_line(list[0]),
    loadT = null,
    placeholder = null;
  el.html(_form_data.html + '<div class="flex justify-end"><div>HTTPS端口：<span class="https-port"></span></div></div><div id="project_domian_list"></div>' + bt.render_help(['建议所有域名都使用默认的80端口']));
  bt.render_clicks(_form_data.clicks);
  // domain样式
  $('.btn_model_submit_domain')
    .addClass('pull-right')
    .css('margin', '30px 35px 0 0');
  $('textarea[name=modeldomain]').css('height', '120px');
  placeholder = $('.placeholder');
  placeholder
    .click(function () {
      $(this).hide();
      $('.modeldomain').focus();
    })
    .css({
      width: '460px',
      heigth: '120px',
      left: '0px',
      top: '0px',
      'padding-top': '10px',
      'padding-left': '15px',
    });
  $('.modeldomain')
    .focus(function () {
      placeholder.hide();
      loadT = layer.tips(placeholder.html(), $(this), {
        tips: [1, '#20a53a'],
        time: 0,
        area: $(this).width(),
      });
    })
    .blur(function () {
      if ($(this).val().length == 0) placeholder.show();
      layer.close(loadT);
    });
  project_domian = bt_tools.table({
    el: '#project_domian_list',
    url: '/project/proxy/get_domain_list',
    default: '暂无域名列表',
    param: { 
      id: row.id,
      site_name: row.name
    },
    height: 375,
    beforeRequest: function (params) {
      if (params.hasOwnProperty('data') && typeof params.data === 'string')
        return params;
      return { data: JSON.stringify(params) };
    },
    dataFilter: function(res) {
      $('.https-port').next().remove()
      $('.https-port').html(res.data.https_port.indexOf('未开启') !== -1 ? '未开启' : res.data.https_port)
      if (res.data.https_port.indexOf('未开启') === -1) {
        $('.https-port').after('<a class="btlink ml5 updata-port">更换</a>')
        $('.updata-port').unbind('click').click(function () {
          bt_tools.open({
            title: '更换端口',
            area: '360px',
            content: {
              class: 'pd20',
              form: [
                {
                  label: 'HTTPS端口',
                  group: {
                    type: 'number',
                    name: 'port',
                    width: '160px'
                  }
                }
              ]
            },
            yes: function (formData, indexs) {
              if (!formData.port) return bt.msg({status: false, msg: 'HTTPS端口不能为空'})
              bt_tools.send({url: '/project/proxy/set_https_port', data: {data: JSON.stringify({ site_name: row.name, port: formData.port })}}, function (res) {
                bt_tools.msg(res)
                if (res.status) project_domian.$refresh_table_list()
              }, '更换端口')
            }
          })
        })
      }
      return {
        data: res?.data?.domain_list || []
      }
    },
    column: [
      { type: 'checkbox', class: '', width: 20 },
      {
        fid: 'name',
        title: '域名',
        type: 'text',
        template: function (_row) {
          return (
            '<a href="http://' +
            _row.name +
            ':' +
            _row.port +
            '" target="_blank" class="btlink">' +
            _row.name +
            '</a>'
          );
        },
      },
      {
        fid: 'port',
        title: '端口',
        type: 'text',
      },
      {
        title: '操作',
        type: 'group',
        width: '100px',
        align: 'right',
        group: [
          {
            title: '删除',
            template: function (row, that) {
              return that.data.length === 1 ? '<span>不可操作</span>' : '删除';
            },
            event: function (rowc, index, ev, key, rthat) {
              if (ev.target.tagName == 'SPAN') return;
              if (rthat.data.length === 1) {
                return bt.msg({ status: false, msg: '最后一个域名不能删除!' });
              }
              bt_tools.send({url: '/project/proxy/del_domain', data: {
                data: JSON.stringify({
                  id: row.id,
                  site_name: row.name,
                  domain: rowc.name,
                  port: rowc.port
                })
              }}, function (res) {
                bt.msg(res);
                rthat.$refresh_table_list(true);
              }, '删除域名')
            },
          },
        ],
      },
    ],
    tootls: [
      {
        // 批量操作
        type: 'batch',
        positon: ['left', 'bottom'],
        placeholder: '请选择批量操作',
        buttonValue: '批量操作',
        disabledSelectValue: '请选择需要批量操作的站点!',
        selectList: [
          {
            title: '删除域名',
            load: true,
            url: '/project/proxy/del_domain',
            param: function (crow) {
              return {
                data: JSON.stringify({
                  id: row.id,
                  site_name: row.name,
                  domain: crow.name,
                  port: crow.port
                }),
              };
            },
            callback: function (that) {
              // 手动执行,data参数包含所有选中的站点
              bt.show_confirm(
                '批量删除域名',
                "<span style='color:red'>同时删除选中的域名，是否继续？</span>",
                function () {
                  var param = {};
                  that.start_batch(param, function (list) {
                    var html = '';
                    for (var i = 0; i < list.length; i++) {
                      var item = list[i];
                      html +=
                        '<tr><td>' +
                        item.name +
                        '</td><td><div style="float:right;"><span style="color:' +
                        (item.requests.status ? '#20a53a' : 'red') +
                        '">' +
                        (item.requests.msg) +
                        '</span></div></td></tr>';
                    }
                    project_domian.$batch_success_table({
                      title: '批量删除',
                      th: '删除域名',
                      html: html,
                    });
                    project_domian.$refresh_table_list(true);
                  });
                }
              );
            },
          },
        ],
      },
    ],
  });
};


/**
 * @description 渲染项目日志
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectLogsView = function (el, row) {
  el.html('<div class="model_project_log"></div>');
  var that = this;
  this.getProjectLog({ project_name: row.name }, function (res) {
    $('#webedit-con .model_project_log').html(
      '<pre class="command_output_pre" style="height:640px;">' +
      (typeof res == 'object' ? res.msg : res) +'</pre>');
    $('#webedit-con .model_project_log').html(
      '<div class="mb10">日志路径<input type="text" name="model_log_path" id="model_log_path" value="'+res.path+'" placeholder="日志路径" class="ml10 bt-input-text mr10" style="width:350px" />\
					<span class="glyphicon glyphicon-folder-open cursor mr10" onclick="bt.select_path(\'model_log_path\',\'dir\')"></span>\
					<button class="btn btn-success btn-sm" name="submitLogConfig">保存</button>\</div>\
					<div class="mb10" style="line-height: 32px;">日志大小<span class="ml10">'+ res.size +'</span></div><pre class="command_output_pre" style="height:500px;">' +
      res.data+
      '</pre>'
    );
    $.post({url: '/project/proxy/get_log_split', data: { name: row.name }}, function (rdata) {
      var html = '',configInfo = {}
      if(rdata.status) configInfo = rdata.data
      html = '开启后' + (rdata.status ? rdata.data.log_size ? '日志文件大小超过'+ bt.format_size(rdata.data.log_size,true,2,'MB') +'时进行切割日志文件' : '每天'+ rdata.data.hour +'点' + rdata.data.minute + '分进行切割日志文件' : '默认每天2点0分进行切割日志文件')
      $('#webedit-con .model_project_log .command_output_pre').before('<div class="inlineBlock log-split mb20" style="line-height: 32px;">\
					<label>\
						<div class="bt-checkbox '+ (rdata.status && rdata.data.status ? 'active':'') +'"></div>\
						<span>日志切割</span>\
					</label>\
					<span class="unit">'+html+'，如需修改请点击<a href="javascript:;" class="btlink mamger_log_split">编辑配置</a></span>\
					</div>')
      $('#webedit-con .model_project_log .log-split').hover(function(){
        layer.tips('当日志文件过大时，读取和搜索时间会增加，同时也会占用存储空间，因此需要对日志进行切割以方便管理和维护。', $(this), {tips: [3, '#20a53a'], time: 0});
      },function(){
        layer.closeAll('tips');
      })
      $('#webedit-con .model_project_log label').click(function(){
        if(rdata['is_old']){
          bt_tools.msg(rdata)
          return;
        }
        bt.confirm({title:'设置日志切割任务',msg: !rdata.status || (rdata.status && !rdata.data.status) ? '开启后对该项目日志进行切割，是否继续操作？' : '关闭后将无法对该项目日志进行切割，是否继续操作？'},function(){
          if(rdata.status){
            that.set_log_split({name: row.name},function(res){
              bt_tools.msg(res)
              if(res.status) {
                that.reanderProjectLogsView(el, row);
              }
            })
          }else{
            that.mamger_log_split({name: row.name},function(res){
              bt_tools.msg(res)
              if(res.status) {
                that.reanderProjectLogsView(el, row);
              }
            })
          }
        })
      })
      $('.mamger_log_split').click(function(){
        if(rdata['is_old']){
          bt_tools.msg(rdata)
          return;
        }
        bt_tools.open({
          type: 1,
          area: '460px',
          title: '配置日志切割任务',
          closeBtn: 2,
          btn: ['提交', '取消'],
          content: {
            'class': 'pd20 mamger_log_split_box',
            form: [{
              label: '执行时间',
              group: [{
                type: 'text',
                name: 'day',
                width: '44px',
                value: '每天',
                disabled: true
              },{
                type: 'number',
                name: 'hour',
                'class': 'group',
                width: '70px',
                value: configInfo.hour || '2',
                unit: '时',
                min: 0,
                max: 23
              }, {
                type: 'number',
                name: 'minute',
                'class': 'group',
                width: '70px',
                min: 0,
                max: 59,
                value: configInfo.minute || '0',
                unit: '分'
              }]
            },{
              label: '日志大小',
              group:{
                type: 'text',
                name: 'log_size',
                width: '220px',
                value: configInfo.log_size ? bt.format_size(configInfo.log_size,true,2,'MB').replace(' MB','') : '',
                unit: 'MB',
                placeholder: '请输入日志大小',
              }
            }, {
              label: '保留最新',
              group:{
                type: 'number',
                name: 'num',
                'class': 'group',
                width: '70px',
                min: 1,
                value: configInfo.num || '180',
                unit: '份'
              }
            }]
          },
          success: function (layero, index) {
            $(layero).find('.mamger_log_split_box .bt-form').prepend('<div class="line">\
								<span class="tname">切割方式</span>\
								<div class="info-r">\
									<div class="replace_content_view" style="line-height: 32px;">\
										<div class="checkbox_config">\
											<i class="file_find_radio '+ (configInfo.log_size ? 'active' : '') +'"></i>\
											<span class="laberText" style="font-size: 12px;">按日志大小</span>\
										</div>\
										<div class="checkbox_config">\
											<i class="file_find_radio '+ (configInfo.log_size ? '' : 'active') +'"></i>\
											<span class="laberText" style="font-size: 12px;">按执行时间</span>\
										</div>\
									</div>\
								</div>')
            $(layero).find('.mamger_log_split_box .bt-form').append('<div class="line"><div class=""><div class="inlineBlock  "><ul class="help-info-text c7"><li>每5分钟执行一次</li><li>【日志大小】：日志文件大小超过指定大小时进行切割日志文件</li><li>【保留最新】：保留最新的日志文件，超过指定数量时，将自动删除旧的日志文件</li></ul></div></div></div>')
            $(layero).find('.replace_content_view .checkbox_config').click(function(){
              var index = $(this).index()
              $(this).find('i').addClass('active').parent().siblings().find('i').removeClass('active')
              if(index){
                $(layero).find('[name=hour]').parent().parent().parent().show()
                $(layero).find('[name=log_size]').parent().parent().parent().hide()
                $(layero).find('.help-info-text li').eq(0).hide().next().hide()
              }else{
                $(layero).find('[name=hour]').parent().parent().parent().hide()
                $(layero).find('[name=log_size]').parent().parent().parent().show()
                $(layero).find('.help-info-text li').eq(0).show().next().show()
              }
            })
            if(configInfo.log_size) {
              $(layero).find('[name=hour]').parent().parent().parent().hide()
            }else{
              $(layero).find('[name=log_size]').parent().parent().parent().hide()
              $(layero).find('.help-info-text li').eq(0).hide().next().hide()
            }
            $(layero).find('[name=log_size]').on('input', function(){
              if($(this).val() < 1 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入日志大小大于0的的整数', $(this), { tips: [1, 'red'], time: 2000 })
              }
            })
            $(layero).find('[name=hour]').on('input', function(){
              if($(this).val() > 23 || $(this).val() < 0 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入小时范围0-23的整数时', $(this), { tips: [1, 'red'], time: 2000 })
              }
              $(layero).find('.hour').text($(this).val())
            })
            $(layero).find('[name=minute]').on('input', function(){
              if($(this).val() > 59 || $(this).val() < 0 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入正确分钟范围0-59分的整数', $(this), { tips: [1, 'red'], time: 2000 })
              }
              $(layero).find('.minute').text($(this).val())
            })
            $(layero).find('[name=num]').on('input', function(){
              if($(this).val() < 1 || $(this).val() > 1800 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入保留最新范围1-1800的整数', $(this), { tips: [1, 'red'], time: 2000 })
              }
            })
          },
          yes: function (formD,indexs) {
            formD['name'] = row.name
            delete formD['day']
            if($('.mamger_log_split_box .file_find_radio.active').parent().index()) {
              if (formD.hour < 0 || formD.hour > 23 || isNaN(formD.hour) || formD.hour === '' || !bt.isInteger(parseFloat(formD.hour))) return layer.msg('请输入小时范围0-23时的整数')
              if (formD.minute < 0 || formD.minute > 59 || isNaN(formD.minute) || formD.minute === '' || !bt.isInteger(parseFloat(formD.minute))) return layer.msg('请输入正确分钟范围0-59分的整数')
              formD['log_size'] = 0
            }else{
              if(formD.log_size == '' || !bt.isInteger(parseFloat(formD.log_size))) return layer.msg('请输入日志大小大于0的的整数')
            }
            if(formD.num < 1 || formD.num > 1800 || !bt.isInteger(parseFloat(formD.num))) return layer.msg('请输入保留最新范围1-1800的整数')
            if(!rdata.status || (rdata.status && !rdata.data.status)) {
              if(rdata.status){
                that.set_log_split({name: row.name},function(res){
                  if(res.status) {
                    pub_open()
                  }
                })
              }else{
                pub_open()
              }
            }else{
              pub_open()
            }
            function pub_open() {
              that.mamger_log_split(formD,function(res){
                bt.msg(res)
                if(res.status) {
                  that.reanderProjectLogsView(el, row);
                  layer.close(indexs)
                }
              })
            }
          }
        })
      })
    })
    // 保存按钮
    $('[name="submitLogConfig"]').unbind('click').click(function () {
      var path = $('#model_log_path').val();
      if (!path) {
        bt.msg({ status: false, msg: '日志路径不能为空' });
        return;
      }
      that.change_log_path({ project_name: row.name, path: path }, function (res) {
        bt.msg(res);
        that.reanderProjectLogsView(el, row);
      });
    })
    $('.command_output_pre').scrollTop(
      $('.command_output_pre').prop('scrollHeight')
    );
  });
};

/**
 * @description 防盗链
 * @param {*} web 
 */
CreateWebsiteModel.prototype.set_security = function (web) {
  site.edit.set_security({id: web.id, name: web.name, type: 'proxy', refresh: function () {
    CreateWebsiteModel.prototype.simulatedClick(6)
  }})
}

/**
 * @description 获取日志
 */
CreateWebsiteModel.prototype.get_site_logs = function (web) {
  $('#webedit-con').append('<div id="tabLogs" class="tab-nav"></div><div class="tab-con" style="padding:10px 0px;"></div>');
  var _tab = [
    {
      title: '网站日志',
      on: true,
      callback: function (robj) {
        bt_tools.send({url: '/project/proxy/GetSiteLogs', data: {data: JSON.stringify({site_name: web.name, type: 'access'})}}, function (res) {
          var rdata = res.data
          var _logs_info = $('<div></div>').text(rdata.msg);
          var logs = { class: 'bt-logs site_log_hover', items: [{ name: 'site_logs', height: '550px', value: _logs_info.html(), width: '100%', type: 'textarea' }] },
            _form_data = bt.render_form_line(logs);
          robj.append('<div class="mb10" style="line-height: 32px;">日志大小<span class="ml10">' +
            rdata.size +
          '</span></div>')
          robj.append(_form_data.html);
          bt.render_clicks(_form_data.clicks);
          $('textarea[name="site_logs"]').css({'white-space': 'pre-wrap', 'word-wrap': 'break-word', 'overflow': 'auto'})
          $('textarea[name="site_logs"]').attr('readonly', true);
          $('textarea[name="site_logs"]').scrollTop(100000000000);
          $('textarea[name="site_logs"]').parent().css('position', 'relative');
          $('textarea[name="site_logs"]').parent().append(
            '<button class="hide full btn btn-sm btn-success"\
                         style="position:absolute;top:10px;right:10px">全屏展示</button>'
          );
          $('.site_log_hover')
            .unbind('hover')
            .hover(
              function (e) {
                $('.full').removeClass('hide');
                e.stopPropagation();
                e.preventDefault();
              },
              function (e) {
                $('.full').addClass('hide');
                e.stopPropagation();
                e.preventDefault();
              }
            );
          bt.site.fullScreenLog(_logs_info, web, '网站');
        },'获取日志');
      },
    },
    {
      title: '错误日志',
      callback: function (robj) {
        bt_tools.send({url: '/project/proxy/GetSiteLogs', data: {data: JSON.stringify({site_name: web.name, type: 'error'})}}, function (res) {
          var rdata = res.data
          var _logs_info = $('<div></div>').text(rdata.msg);
          var logs = { class: 'bt-logs error_log_hover', items: [{ name: 'site_logs', height: '550px', value: _logs_info.html(), width: '100%', type: 'textarea' }] },
            _form_data = bt.render_form_line(logs);
          robj.append('<div class="mb10" style="line-height: 32px;">日志大小<span class="ml10">' +
            rdata.size +
          '</span></div>')
          robj.append(_form_data.html);
          bt.render_clicks(_form_data.clicks);
          $('textarea[name="site_logs"]').css({'white-space': 'pre-wrap', 'word-wrap': 'break-word', 'overflow': 'auto'})
          $('textarea[name="site_logs"]').attr('readonly', true);
          $('textarea[name="site_logs"]').scrollTop(100000000000);
          $('textarea[name="site_logs"]').parent().css('position', 'relative');
          $('textarea[name="site_logs"]').parent().append(
            '<button class="hide full btn btn-sm btn-success"\
            style="position:absolute;top:10px;right:10px">全屏展示</button>'
          );
          $('.error_log_hover')
            .unbind('hover')
            .hover(
              function (e) {
                $('.full').removeClass('hide');
                e.stopPropagation();
                e.preventDefault();
              },
              function (e) {
                $('.full').addClass('hide');
                e.stopPropagation();
                e.preventDefault();
              }
            );
          bt.site.fullScreenLog(_logs_info, web, '错误');
        },'获取日志');
      },
    },
    {
      title: '日志安全分析',
      callback: function (robj) {
        var progress = ''; //扫描进度
        $.post('/site?action=get_scan_files&siteName=' + web.name, function (fileList) {
          //1.扫描按钮/日志列表
          var logOption = '';
          if (fileList.data.length > 0) {
            $.each(fileList.data, function (index, item) {
              logOption += '<option value="' + item + '">' + item + '</option>';
            });
          }
          var analyes_log_btn =
            '<select class="bt-input-text mr5" name="scan_log_file">' +
            logOption +
            '</select><button type="button" title="日志扫描" class="btn btn-success analyes_log btn-sm mr5"><span>日志扫描</span></button>';

          //2.功能介绍
          var analyse_help =
            '<ul class="help-info-text c7">\
                    <li>日志安全分析：扫描网站(.log)日志中含有攻击类型的请求(类型包含：<em style="color:red">xss,sql,scan,php</em>)</li>\
                    <li>分析的日志数据包含已拦截的请求</li>\
                    <li>默认展示上一次扫描数据(如果没有请点击日志扫描）</li>\
                    <li>如日志文件过大，扫描可能等待时间较长，请耐心等待</li>\
                    </ul>';

          robj.append(analyes_log_btn + '<div class="analyse_log_table"></div>' + analyse_help);
          render_analyse_list(); //加载模板
          //首次获取进度
          detect_progress('init', function () {
            var loadT = bt.load('正在获取日志分析数据，请稍候...');
            $.post('/site?action=get_scan_result&siteName=' + web.name, function (rdata) {
              loadT.close();
              render_analyse_list(rdata);
            });
            //事件
            $(robj)
              .find('.analyes_log')
              .click(function () {
                var _file = $('[name=scan_log_file]').val();
                if (!_file) return layer.msg('没有日志文件', { icon: 2 });

                bt.confirm(
                  {
                    title: '扫描网站日志',
                    msg: '建议在服务器负载较低时进行安全分析，本次将对【' + _file + '】文件进行扫描，可能等待时间较长，是否继续？',
                  },
                  function (index) {
                    layer.close(index);
                    $('.analyes_log').attr('disabled', true);
                    // 开启扫描并且持续获取进度
                    $.post('/site?action=start_scan_logs&siteName=' + web.name + '&path=' + _file, function (rdata) {
                      if (rdata.status) {
                        open_scan_dialog();
                      } else {
                        layer.close(progress);
                        layer.msg(rdata.msg, { icon: 2, time: 0, shade: 0.3, shadeClose: true });
                      }
                    });
                  }
                );
              });
          });
        });

        // 渲染分析日志列表
        function render_analyse_list(rdata) {
          var analyse_list =
            '<div class="divtable" style="margin-top: 10px;"><table class="table table-hover">\
                    <thead><tr><th>文件名</th><th width="142">扫描时间</th><th>总条数</th><th>耗时</th><th>XSS</th><th>SQL</th><th>扫描</th><th>PHP攻击</th><th>合计</th></tr></thead>\
                    <tbody class="analyse_body">';
          if (rdata && rdata.length > 0) {
            //检测是否有扫描数据
            $.each(rdata, function (index, item) {
              var numTotal = item.xss + item.sql + item.scan + item.php;
              analyse_list +=
                '<tr name="' +
                item.filename +
                '">\
                                <td title="' +
                item.filepath +
                '"><span class="size_ellipsis" style="width:90px">' +
                item.filename +
                '</span></td>\
                                <td>' +
                bt.format_data(item.start) +
                '</td>\
                                <td>' +
                item.total +
                '</td>\
                                <td>' +
                item.time.toString().substring(0, 4) +
                '秒</td>\
                                <td class="onChangeLogDatail" ' +
                (item.xss > 0 ? 'style="color:red"' : '') +
                ' name="xss">' +
                item.xss +
                '</td>\
                                <td class="onChangeLogDatail" ' +
                (item.sql > 0 ? 'style="color:red"' : '') +
                ' name="sql">' +
                item.sql +
                '</td>\
                                <td class="onChangeLogDatail" ' +
                (item.scan > 0 ? 'style="color:red"' : '') +
                ' name="scan">' +
                item.scan +
                '</td>\
                                <td class="onChangeLogDatail" ' +
                (item.php > 0 ? 'style="color:red"' : '') +
                ' name="php">' +
                item.php +
                '</td>\
                                <td>' +
                numTotal +
                '</td>\
                            </tr>';
            });
          } else {
            analyse_list += '<tr><td colspan="9" style="text-align: center;">没有扫描数据</td></tr>';
          }

          analyse_list += '</tbody></table></div>';
          $('.analyse_log_table').html(analyse_list);
          $('.onChangeLogDatail').css('cursor', 'pointer').attr('title', '点击查看详情');
          //查看详情
          $('.onChangeLogDatail').on('click', function () {
            get_analysis_data_datail($(this).attr('name'), $(this).parents('tr').attr('name'));
          });
          $('.analyes_log').attr('disabled', false);
        }
        // 扫描进度界面
        function open_scan_dialog() {
          progress = layer.open({
            type: 1,
            closeBtn: 1,
            title: '日志扫描',
            shade: 0,
            maxmin: true,
            area: '500px',
            skin: 'scan_logs_view',
            content:
              '<div class="pro_style">\
                            <pre style="margin-bottom: 0px;height:300px;border-radius:0px; text-align: left;background-color: #000;color: #fff;white-space: pre-wrap;" id="scan_result_progress"></pre>\
                            </div>',
            success: function () {
              detect_progress();
            },
            full: function () {
              $('#scan_result_progress').height($('.scan_logs_view .layui-layer-content').height() - 50);
            },
            restore: function () {
              $('#scan_result_progress').height('279px');
            },
            cancel: function (index) {
              layer.confirm(
                '正在对日志扫描中，此操作将会停止日志扫描，是否继续？',
                {
                  title: '停止扫描',
                  icon: 0,
                },
                function (indexs) {
                  $.post('/site?action=stop_scan_logs&siteName=' + web.name, function (rdata) {
                    if (rdata.status) {
                      layer.close(indexs);
                    }
                    layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                  });
                }
              );
              return false;
            },
          });
        }
        // 扫描进度
        function detect_progress(type, callback) {
          $.post('/site?action=speed_log&siteName=' + web.name, function (res) {
            var pro = res.code;
            if (type == 'init' && pro != 1) {
              // 是否有扫描进度界面
              if ($('#scan_result_progress').length > 0) {
                detect_progress();
              } else {
                open_scan_dialog();
              }
              $('.analyes_log').attr('disabled', true);
            } else if (type == 'init' && pro == 1) {
              callback();
            } else {
              if (pro !== 1) {
                $('#scan_result_progress').html(res.msg).scrollTop(100000000000);
                setTimeout(function () {
                  detect_progress();
                }, 1000);
              } else {
                layer.close(progress);
                get_analysis_data();
                setTimeout(function () {
                  layer.msg('扫描完成', { icon: 1, timeout: 4000 });
                }, 1000)
              }
            }
          });
        }
        // 获取扫描结果
        function get_analysis_data() {
          var loadTGA = bt.load('正在获取日志分析数据，请稍候...');
          $.post('/site?action=get_scan_result&siteName=' + web.name, function (rdata) {
            loadTGA.close();
            render_analyse_list(rdata);
          });
        }
        // 获取扫描结果详情日志
        function get_analysis_data_datail(name, filename) {
          layer.open({
            type: 1,
            closeBtn: 1,
            shadeClose: false,
            maxmin: true,
            title: '【文件：' + filename + '】【类型：' + name + '】日志详情',
            area: '650px',
            skin: 'scan_type_details',
            content: '<pre id="analysis_pre" style="background-color: #333;color: #fff;height:545px;margin: 0;white-space: pre-wrap;border-radius: 0;"></pre>',
            success: function () {
              var loadTGD = bt.load('正在获取日志详情数据，请稍候...');
              $.post('/site?action=get_detailed&siteName=' + web.name + '&filename=' + filename + '&type=' + name + '', function (logs) {
                loadTGD.close();
                $('#analysis_pre').html(logs.msg);
              });
            },
            full: function () {
              $('#analysis_pre').height($('.scan_type_details .layui-layer-content').height() - 50);
            },
            restore: function () {
              $('#analysis_pre').height('524px');
            },
          });
        }
      },
    },
  ];
  bt.render_tab('tabLogs', _tab);
  $('#tabLogs span:eq(0)').click();
};