#coding: utf-8
#  + -------------------------------------------------------------------
# | aaPanel
#  + -------------------------------------------------------------------
# | Copyright (c) 2015-2016 aaPanel(www.aapanel.com) All rights reserved.
#  + -------------------------------------------------------------------
# | Author: hezhihong <272267659@@qq.cn>
#  + -------------------------------------------------------------------
import json
import traceback
import sys
import re
if not '/www/server/panel/class/' in sys.path:
    sys.path.insert(0, '/www/server/panel/class/')
import public, os, time
from logsModelV2.base import logsBase
import datetime
import crontab
from public.validate import Param

try:
    from BTPanel import session
except:
    pass
# 英文转月份缩写
month_list = {
    "Jan": "1",
    "Feb": "2",
    "Mar": "3",
    "Apr": "4",
    "May": "5",
    "Jun": "6",
    "Jul": "7",
    "Aug": "8",
    "Sept": "9",
    "Sep": "9",
    "Oct": "10",
    "Nov": "11",
    "Dec": "12"
}


class main(logsBase):
    analysis_config_path = '/www/server/panel/data/analysis_config.json'
    white_list_path = '/www/server/panel/data/ftp_white_list.json'
    __AUTH_MSG =public.to_string ([84 ,104 ,105 ,115 ,32 ,102 ,101 ,97 ,116 ,117 ,114 ,101 ,32 ,105 ,115 ,32 ,101 ,120 ,99 ,108 ,117 ,115 ,105 ,118 ,101 ,32 ,116 ,111 ,32 ,116 ,104 ,101 ,32 ,112 ,114 ,111 ,32 ,101 ,100 ,105 ,116 ,105 ,111 ,110 ,44 ,32 ,112 ,108 ,101 ,97 ,115 ,101 ,32 ,97 ,99 ,116 ,105 ,118 ,97 ,116 ,101 ,32 ,105 ,116 ,32 ,102 ,105 ,114 ,115 ,116 ])

    def __init__(self):
        self.__messages_file = "/var/log/"
        self.__ftp_backup_path = public.get_backup_path() + '/pure-ftpd/'
        if not os.path.isdir(self.__ftp_backup_path):
            public.ExecShell('mkdir -p {}'.format(self.__ftp_backup_path))
        self.__script_py = public.get_panel_path() + '/script/ftplogs_cut.py'
        self.white_list = self.get_white_list(None)['message']

    def __check_auth(self):
        from plugin_auth_v2 import Plugin as Plugin
        plugin_obj = Plugin(False)
        plugin_list = plugin_obj.get_plugin_list()
        import PluginLoader
        self.__IS_PRO_MEMBER = PluginLoader.get_auth_state() > 0
        return int(plugin_list["pro"]) > time.time() or self.__IS_PRO_MEMBER

    def get_file_list(self, path, is_bakcup=False):
        """
        @name 取所有messages日志文件
        @param path: 日志文件路径
        @return: 返回日志文件列表
        """
        files = os.listdir(path)
        if is_bakcup:
            file_name_list = [{
                "file": "/var/log/pure-ftpd.log",
                "time": int(time.time())
            }]
        else:
            file_name_list = []
        for i in files:
            tmp_dict = {}
            if not i: continue
            file_path = path + i
            tmp_dict['file'] = file_path
            if is_bakcup:
                if os.path.isfile(file_path) and i.find('pure-ftpd.log') != -1:
                    tmp_dict['time'] = int(
                        public.to_date(
                            times=os.path.basename(file_path).split('_')[0] +
                                  ' 00:00:00'))
                    file_name_list.append(tmp_dict)
            else:
                if os.path.isfile(file_path) and i.find('messages') != -1:
                    tmp_dict['time'] = int(
                        public.to_date(
                            times=os.path.basename(file_path).split('-')[1] +
                                  ' 00:00:00'))
                    file_name_list.append(tmp_dict)
        file_name_list = sorted(file_name_list,
                                key=lambda x: x['time'],
                                reverse=False)
        return file_name_list

    def set_ftp_log(self, get):
        """
        @name 开启、关闭、获取日志状态
        @author hezhihong
        @param get.exec_name 执行的动作
        """
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)

        # 校验参数
        try:
            get.validate([
                Param('exec_name').String(),

            ], [
                public.validate.trim_filter(),
            ])
        except Exception as ex:
            public.print_log("error info: {}".format(ex))
            return public.return_message(-1, 0, str(ex))

        if not hasattr(get, 'exec_name'):
            return public.return_message(-1, 0, public.lang("The parameter is incorrect！"))
        conf_path = '/etc/rsyslog.conf'
        ftp_file='/etc/rsyslog.d/pure-ftpd.conf'
        if not os.path.exists(conf_path):
            return public.return_message(-1, 0, public.lang("The rsyslog configuration file does not exist!\nPlease check if rsyslog is installed or if /etc/rsyslog.conf exists!\nIf the debain system is not installed, please execute：apt-get install rsyslog\nPlease execute the Centos system：yum install rsyslog"))
        write_string = '\nftp.*\t\t-/var/log/pure-ftpd.log\n'
        # 获取日志状态
        if get.exec_name == 'getlog':
            if os.path.exists(ftp_file):
                return public.return_message(0, 0, public.lang("start"))
            else:
                return public.return_message(0, 0, public.lang("stop"))
        # 开启日志审计
        elif get.exec_name == 'start':
            public.writeFile(ftp_file, write_string)
            # ubuntu/debian中不存在pure-ftpd.log文件，需要创建并赋权
            log_file = '/var/log/pure-ftpd.log'
            if not os.path.exists(log_file):
                public.ExecShell('touch {}'.format(log_file))
                public.ExecShell('chmod 640 /var/log/pure-ftpd.log')
                public.ExecShell('chown syslog:adm /var/log/pure-ftpd.log')
                public.ExecShell('sudo useradd -r -s /sbin/nologin ftp')
                public.ExecShell('systemctl restart pure-ftpd ')
            self.add_crontab()
        # 关闭日志审计
        elif get.exec_name == 'stop':
            if os.path.exists(ftp_file):
                os.remove(ftp_file)
                if os.path.exists(ftp_file):
                    return public.return_message(-1, 0, public.lang("failed to close the log"))
            self.del_crontab()
        public.ExecShell('systemctl restart rsyslog')
        return public.return_message(0, 0, public.lang("successfully set"))

    def get_format_time_bak(self, englist_time):
        date_part = englist_time[8:10]
        if date_part.startswith('0'):
            date_part=date_part[1:]
        day_part = englist_time[11:13]
        if day_part.startswith('0'):
            day_part=day_part[1:]
        time_part = englist_time[11:19]
        return "{}-{} {}".format(date_part,day_part,time_part)

    def get_format_time(self, englist_time):
        """
        @name 时间英文转换
        """
        chinanese_time = ''
        try:
            for i in month_list.keys():
                if i in englist_time:
                    tmp_time = englist_time.replace(i, month_list[i])
                    tmp_time = tmp_time.split()
                    chinanese_time = '{}-{} {}'.format(tmp_time[0], tmp_time[1],
                                                       tmp_time[2])
                    break
            if chinanese_time=='':
                chinanese_time = self.get_format_time_bak(englist_time)
            return chinanese_time
        except:
            if chinanese_time=='':
                chinanese_time = self.get_format_time_bak(englist_time)
            return chinanese_time

    def get_login_log(self, get):
        """
        @name 取登录日志
        @author hezhihong
        @param get.user_name ftp用户名
        return
        """
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)

        # 校验参数
        try:
            get.validate([
                Param('p').Integer(),
                Param('limit').Integer(),
                Param('search').String(),
                Param('user_name').String(),

            ], [
                public.validate.trim_filter(),
            ])
        except Exception as ex:
            public.print_log("error info: {}".format(ex))
            return public.return_message(-1, 0, str(ex))

        search_str = 'pure-ftpd:'
        if not hasattr(get, 'user_name'):
            return public.return_message(-1, 0, public.lang("The parameter is incorrect！"))
        args = public.dict_obj()
        args.exec_name = 'getlog'
        file_name = self.__ftp_backup_path
        is_backup = True
        if self.set_ftp_log(get) == 'stop':
            file_name = self.__messages_file
            is_backup = False
        file_list = self.get_file_list(file_name, is_backup)
        sortid = 0
        tmp_dict = {}
        login_all = []
        for file in file_list:

            if not os.path.isfile(file['file']): continue
            conf = public.readFile(file['file'])
            lines = conf.split('\n')
            for line in lines:
                if not line: continue
                login_info = {}
                if search_str not in line: continue
                tmp_value = ' is now logged in'
                info = line[:line.find(search_str)].strip()
                hostname = info.split()[-1]
                exec_time = info.split(hostname)[0].strip()
                exec_time = self.get_format_time(exec_time)
                ip = line[line.find('(') + 1:line.find(')')].split('@')[1]

                # 取登录成功日志
                if tmp_value in line:
                    user = line.split(tmp_value)[0].strip().split()[-1]
                    if user == '?' or user != get.user_name: continue
                    dict_index = '{}__{}'.format(user, ip)
                    if dict_index not in tmp_dict:
                        tmp_dict[dict_index] = []
                    tmp_dict[dict_index].append(exec_time)

                # 取登出日志
                tmp_value = '[INFO] Logout.'
                tmp_value_two = 'Timeout - try typing a little faster next time'
                if tmp_value in line or tmp_value_two in line:
                    user = line[line.find('(') +
                                1:line.find(')')].split('@')[0]
                    if user == '?' or user != get.user_name: continue
                    dict_index = '{}__{}'.format(user, ip)
                    try:
                        login_info['out_time'] = exec_time
                        login_info['in_time'] = tmp_dict[dict_index][0]
                        login_info['user'] = user
                        login_info['ip'] = ip
                        login_info['status'] = 'Success'  # 0为登录失败，1为登录成功
                        login_info['sortid'] = sortid
                        login_all.append(login_info)
                        tmp_dict[dict_index] = []
                        sortid += 1
                    except:
                        pass
                # 取登录失败日志
                tmp_value = 'Authentication failed for user'
                if tmp_value in line:
                    user = line.split(tmp_value)[-1].replace('[', '').replace(
                        ']', '').strip()
                    if user == '?' or user != get.user_name: continue
                    login_info['user'] = user
                    login_info['ip'] = ip
                    login_info['status'] = 'Failure'  # 0为登录失败，1为登录成功
                    login_info['in_time'] = exec_time
                    login_info['out_time'] = exec_time
                    login_info['sortid'] = sortid
                    login_all.append(login_info)
                    sortid += 1

        if tmp_dict:
            for item in tmp_dict.keys():
                if not tmp_dict[item]: continue
                info = {
                    "status": "Success",
                    "in_time": tmp_dict[item][0],
                    "out_time": "connecting",
                    "user": item.split('__')[0],
                    "ip": item.split('__')[1],
                    "sortid": sortid
                }
                sortid += 1
                login_all.append(info)

        data = []
        # 搜索过滤
        if login_all and 'search' in get and get.search and get.search.strip():
            for info in login_all:
                try:
                    search_str = str(get.search).strip().lower()
                    # public.writeFile('/tmp/aa.aa', get.search)
                    if info['ip'].find(search_str) != -1 or info['user'].lower(
                    ).find(search_str) != -1 or info['status'].find(
                        search_str) != -1 or info['in_time'].find(
                        search_str) != -1:
                        data.append(info)
                    elif info['out_time'] and info['out_time'].find(
                            search_str) != -1:
                        data.append(info)
                except:
                    pass
        else:
            data = login_all

        data = sorted(data, key=lambda x: x['sortid'], reverse=True)
        return self.get_page(data, get)

    def get_page(self, data, get):
        """
            @name 取分页
            @author hezhihong
            @param data 需要分页的数据 list
            @param get.p 第几页
            @return 指定分页数据
            """
        # 包含分页类
        import page
        # 实例化分页类
        page = page.Page()

        info = {}
        info['count'] = len(data)
        info['row'] = int(getattr(get, "limit", 10))
        info['p'] = 1
        if hasattr(get, 'p'):
            info['p'] = int(get['p'])
        info['uri'] = {}
        info['return_js'] = ''
        # 获取分页数据
        result = {}
        result['page'] = page.GetPage(info, limit='1,2,3,4,5,8')
        n = 0
        result['data'] = []
        for i in range(info['count']):
            if n >= page.ROW: break
            if i < page.SHIFT: continue
            n += 1
            result['data'].append(data[i])
        return public.return_message(0,0,result)

    def get_action_log(self, get):
        """
        @name 取操作日志
        @author hezhihong
        @param get.user_name ftp用户名
        return {"upload":[],"download":[],"rename":[],"delete":[]}
        """
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)

        # 校验参数
        try:
            get.validate([
                Param('p').Integer(),
                Param('limit').Integer(),
                Param('search').String(),
                Param('user_name').String(),
                Param('type').String(),

            ], [
                public.validate.trim_filter(),
            ])
        except Exception as ex:
            public.print_log("error info: {}".format(ex))
            return public.return_message(-1, 0, str(ex))


        search_str = 'pure-ftpd:'
        args = public.dict_obj()
        args.exec_name = 'getlog'
        file_name = self.__ftp_backup_path
        is_backup = True
        if self.set_ftp_log(get) == 'stop':
            file_name = self.__messages_file
            is_backup = False
        file_list = self.get_file_list(file_name, is_backup)
        if not hasattr(get, 'user_name'):
            return public.return_message(-1, 0, public.lang("The parameter is incorrect！"))
        data = []
        tmp_data = []
        sortid = 0
        for file in file_list:
            if not os.path.isfile(file['file']): continue
            conf = public.readFile(file['file'])
            lines = conf.split('\n')
            for line in lines:
                if not line: continue
                action_info = {}
                if search_str not in line: continue
                tmp_v = line.split(search_str)
                # debian时区格式为 ISO 8601 标准，做转换
                if len(tmp_v[0].strip().split())<3:
                    os_version = public.get_os_version().lower()
                    if "debian" in os_version:
                        tmp_list = tmp_v[0].strip().split()
                        tmp_v[0] = self.convert_timestamp(tmp_list[0]) + ' debian'
                    else:
                        continue

                hostname = tmp_v[0].strip().split()[3].strip()
                action_time = tmp_v[0].replace(hostname, '').strip()
                action_info['time'] = self.get_format_time(action_time)

                upload_value = ' uploaded '
                download_value = ' downloaded '
                rename_value = 'successfully renamed or moved:'
                delete_value = ' Deleted '
                ip = line[line.find('(') + 1:line.find(')')].split('@')[1]
                action_info['ip'] = ip
                action_info['type'] = ''
                # 取操作用户
                user = ''
                if upload_value in line or download_value in line or rename_value in line or delete_value in line:
                    user = line[line.find('(') +
                                1:line.find(')')].split('@')[0]
                    action_info['sortid'] = sortid
                    sortid = sortid + 1
                if not user or user != get.user_name: continue
                action_info['user'] = get.user_name
                # 取上传日志
                if (get.type == 'all'
                    or get.type == 'upload') and upload_value in line:
                    line_list = line.split()
                    upload_index = line_list.index('uploaded')
                    # action_info['file'] = line_list[upload_index - 1].replace(
                    #     '//', '/')
                    action_info['file'] = line[line.find(']') +
                                               1:line.rfind('(')].replace(
                        'uploaded',
                        '').replace('//',
                                    '/').strip()
                    action_info['type'] = 'upload'
                    tmp_data.append(action_info)
                # 取下载日志
                if (get.type == 'all'
                    or get.type == 'download') and download_value in line:
                    line_list = line.split()
                    upload_index = line_list.index('downloaded')
                    action_info['file'] = line_list[upload_index - 1].replace(
                        '//', '/')
                    action_info['type'] = 'download'
                    tmp_data.append(action_info)
                # 取重命名日志
                if (get.type == 'all'
                    or get.type == 'rename') and rename_value in line:
                    action_info['file'] = line.split(rename_value)[1].replace(
                        '->', 'Renamed to').strip().replace('//', '/')
                    action_info['type'] = 'rename'
                    tmp_data.append(action_info)
                # 取删除日志
                if (get.type == 'all'
                    or get.type == 'delete') and delete_value in line:
                    action_info['file'] = line.split()[-1].strip().replace(
                        '//', '/')
                    action_info['type'] = 'delete'
                    tmp_data.append(action_info)
            # f.close
        # 搜索过滤
        if tmp_data and 'search' in get and get.search and get.search.strip():
            for info in tmp_data:
                search_str = str(get.search).strip().lower()
                if info['ip'].find(search_str) != -1 or info['file'].lower(
                ).find(search_str) != -1 or info['type'].find(
                    search_str) != -1 or info['time'].find(
                    search_str) != -1 or get.user_name.lower().find(
                    search_str) != -1:
                    data.append(info)
        else:
            for info2 in tmp_data:
                data.append(info2)
        data = sorted(data, key=lambda x: x['sortid'], reverse=True)
        return self.get_page(data, get)

    def del_crontab(self):
        """
        @name 删除项目定时清理任务
        @auther hezhihong<2022-10-31>
        @return
        """
        cron_name = '[Do not delete] FTP audit log cutting task'
        cron_path = public.GetConfigValue('setup_path') + '/cron/'
        cron_list = public.M('crontab').where("name=?", (cron_name,)).select()
        if cron_list:
            for i in cron_list:
                if not i: continue
                cron_echo = public.M('crontab').where(
                    "id=?", (i['id'],)).getField('echo')
                args = {"id": i['id']}
                import crontab
                crontab.crontab().DelCrontab(args)
                del_cron_file = cron_path + cron_echo
                public.ExecShell(
                    "crontab -u root -l| grep -v '{}'|crontab -u root -".
                    format(del_cron_file))

    def add_crontab(self):
        """
        @name 构造日志切割任务
        """
        python_path = ''
        try:
            python_path = public.ExecShell('which btpython')[0].strip("\n")
        except:
            # 使用备用解释器
            python_candidates = [
                '/www/server/panel/pyenv/bin/python3',
                '/www/server/panel/pyenv/bin/python',
                'which python3',
                'which python'
            ]
            for candidate in python_candidates:
                if candidate.startswith('/'):
                    if os.path.exists(candidate):
                        python_path = candidate
                        break
                else:
                    try:
                        python_path = public.ExecShell(candidate)[0].strip("\n")
                        if python_path:
                            break
                    except:
                        pass
        if not python_path: return False
        if not public.M('crontab').where('name=?',
                                         ('[Do not delete] FTP audit log cutting task',)).count():
            cmd = '{} {}'.format(python_path, self.__script_py)
            args = {
                "name": "[Do not delete] FTP audit log cutting task",
                "type": 'day',
                "where1": '',
                "hour": '0',
                "minute": '1',
                "sName": "",
                "sType": 'toShell',
                "notice": '0',
                "notice_channel": '',
                "save": '',
                "save_local": '1',
                "backupTo": '',
                "sBody": cmd,
                "urladdress": ''
            }
            import crontab
            res = crontab.crontab().AddCrontab(args)
            if res and "id" in res.keys():
                return True
            return False
        return True

    # ftp日志分析
    def log_analysis(self, get):
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)

        # 校验参数
        try:
            get.validate([
                Param('search').String(),
                Param('username').String(),
                Param('day').Integer(),

            ], [
                public.validate.trim_filter(),
            ])
        except Exception as ex:
            public.print_log("error info: {}".format(ex))
            return public.return_message(-1, 0, str(ex))

        try:
            public.set_module_logs('ftp_log_analysis', 'ftp_log_analysis', 1)
            self.ftp_user = public.M('ftps').field('id,name').select()
            self.ftp_user = {i['name']: i['id'] for i in self.ftp_user}
            if not hasattr(get, 'search'):
                return public.return_message(-1, 0, public.lang("The parameter is incorrect！"))
            day = 0
            if hasattr(get, 'day') and get.day:
                day = int(get.day)
                time = datetime.datetime.now() - datetime.timedelta(days=day)
                time = time - datetime.timedelta(hours=time.hour,
                                                 minutes=time.minute,
                                                 seconds=time.second)
                day = int(time.timestamp())
            username = []
            if hasattr(get, 'username') and get.username:
                username = json.loads(get.username)
            search = json.loads(get.search)
            file_name = self.__ftp_backup_path
            is_backup = True
            # 获取切割文件的日志文件列表
            file_list = self.get_file_list(file_name, is_backup)
            self.result = {}
            config = self.get_analysis_config(None)['message']
            time, area, upload_shell, num = config['time'], config['area'], config['upload_shell'], config['login_error']
            self.login_error_dict = {}
            for file in file_list:
                if int(file['time']) < day: continue
                if not os.path.isfile(file['file']): continue
                log = public.readFile(file['file'])
                log = log.strip().split('\n')
                for i in log:
                    if not i: continue
                    if username:
                        user = i[i.find('(') + 1:i.find(')')].split('@')[0]
                        if user not in username:
                            continue
                    if day:
                        hostname = i.split()[-1]
                        exec_time =exec_time_bak= i.split(hostname)[0].strip()
                        # 判断时区类型
                        if self.is_iso8601(exec_time.split(' ')[0]):
                            exec_time = self.convert_timestamp(exec_time.split(' ')[0])
                        exec_time = self.get_format_time(exec_time)
                        if exec_time=='':
                            # 使用str.split()方法分割字符串，取日期时间部分
                            date_time_part = exec_time_bak.split(' ')[0]

                            # 创建datetime对象，注意这里没有直接处理时区，因为输出要求不涉及时区转换
                            dt_obj = datetime.fromisoformat(date_time_part.replace("T", " "))

                            # 格式化日期时间
                            exec_time = dt_obj.strftime('%-m-%-d %H:%M:%S')
                        a_time = int(datetime.datetime.strptime(str(datetime.datetime.now().year) + '-' + exec_time, '%Y-%m-%d %H:%M:%S').timestamp())
                        if a_time < day: continue
                    ip = i[i.find('(') + 1:i.find(')')].split('@')[1]
                    if ip == '?': continue
                    if 'anonymous' in search:
                        self.screening_anonymous(i)
                    if 'time' in search:
                        self.screening_time(i, time)
                    if 'area' in search:
                        self.screening_area(i, area)
                    if 'upload_shell' in search:
                        self.upload_shell(i, upload_shell)
            if 'login_error' in search:
                self.login_error(file_list, num, day, username)
            return public.return_message(0,0,self.result)
        except:
            return public.return_message(-1,0,traceback.format_exc())

    # 获取筛选配置
    def get_analysis_config(self, get):
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)
        if os.path.exists(self.analysis_config_path):
            data = json.loads(public.readFile(self.analysis_config_path))
        else:
            data = {
                'time': {'start_time': 0, 'end_time': 6},
                'area': {'country': [], 'city': []},
                'upload_shell': ['js', 'php', 'py', 'jar', 'sh', 'rb', 'pl', 'bat', 'vbs', 'ps1', 'lua', 'r', 'ts', 'cs', 'java', 'awk', 'swift', 'ksh', 'csh', 'fish'],
                'login_error': 5,
                'cron_task_status': 0
            }
            public.writeFile(self.analysis_config_path, json.dumps(data))
        if not public.M('crontab').where('name=?', ('[Do not delete] FTP audit log cutting task',)).count():
            data['cron_task_status'] = 0
        return public.return_message(0,0,data)

    # 设置筛选配置
    def set_analysis_config(self, get):
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)

        # 校验参数
        try:
            get.validate([
                Param('login_error').Integer(),
                Param('time').String(),
                Param('area').String(),
                Param('upload_shell').String(),


            ], [
                public.validate.trim_filter(),
            ])
        except Exception as ex:
            public.print_log("error info: {}".format(ex))
            return public.return_message(-1, 0, str(ex))


        try:
            config = json.loads(public.readFile(self.analysis_config_path))
            if hasattr(get, 'time'):
                config['time'] = json.loads(get.time)
            if hasattr(get, 'area'):
                config['area'] = json.loads(get.area)
            if hasattr(get, 'upload_shell'):
                config['upload_shell'] = json.loads(get.upload_shell)
            if hasattr(get, 'login_error'):
                config['login_error'] = int(get.login_error)
            public.writeFile(self.analysis_config_path, json.dumps(config))
            return public.return_message(0, 0, public.lang("successfully set"))
        except:
            return public.return_message(-1, 0, public.lang("failed set"))

    # 匿名登录筛选
    def screening_anonymous(self, i):
        if '(?@' not in i and 'anonymous' not in i: return
        hostname = i.split()[-1]
        exec_time = i.split(hostname)[0].strip()
        exec_time = self.get_format_time(exec_time)
        ip = i[i.find('(') + 1:i.find(')')].split('@')[1]
        user = i[i.find('(') + 1:i.find(')')].split('@')[0]
        self.write_result(ip, exec_time, user, 'anonymous logon')

    # 登录时间筛选
    def screening_time(self, i, time):
        start_time = int(time['start_time'])
        end_time = int(time['end_time'])
        hostname = i.split()[-1]
        exec_time = i.split(hostname)[0].strip()
        exec_time = self.get_format_time(exec_time)
        hour = int(exec_time.split()[1].split(':')[0])
        if start_time <= hour <= end_time:
            return
        ip = i[i.find('(') + 1:i.find(')')].split('@')[1]
        user = i[i.find('(') + 1:i.find(')')].split('@')[0]
        self.write_result(ip, exec_time, user, 'Abnormal login time')

    # 地区筛选
    def screening_area(self, i, area):
        hostname = i.split()[-1]
        exec_time = i.split(hostname)[0].strip()
        exec_time = self.get_format_time(exec_time)
        ip = i[i.find('(') + 1:i.find(')')].split('@')[1]
        user = i[i.find('(') + 1:i.find(')')].split('@')[0]
        try:
            iparea = public.get_ip_location(ip)
        except:
            return
        if not iparea: return
        if not iparea.raw["country"]["country"]: return
        if iparea.raw["country"]["country"] == '内网地址': return
        # if iparea.raw["country"]["country"] in area['country'] or iparea.raw["country"]["city"] in area['city']:
        if iparea.raw["country"]["country"] in area['country'] :
            return
        self.write_result(ip, exec_time, user, 'Login Region Exception')

    # 上传脚本文件检测
    def upload_shell(self, i, Suffix):
        if 'uploaded' not in i: return
        hostname = i.split()[-1]
        exec_time = i.split(hostname)[0].strip()
        exec_time = self.get_format_time(exec_time)
        ip = i[i.find('(') + 1:i.find(')')].split('@')[1]
        user = i[i.find('(') + 1:i.find(')')].split('@')[0]
        file = i[i.find(']') + 1:i.rfind('(')].replace('uploaded', '').replace('//', '/').strip()
        if file.split('.')[-1] not in Suffix: return
        self.write_result(ip, exec_time, user, 'Upload script file')

    # 登录爆破检测
    def login_error(self, file_list, num, day, username):
        try:
            import pandas as pd
        except:
            public.ExecShell('btpip install pandas')
            import pandas as pd
        pd.options.mode.chained_assignment = None
        data = self.parse_log(file_list, day, username)
        if not data: return
        df = pd.DataFrame(data)
        # 将时间戳转换为datetime类型
        df.loc[:, 'exec_time'] = pd.to_datetime(df['exec_time'], format='%Y-%m-%d %H:%M:%S')
        time_window = '5T'
        df['count'] = df.groupby(['ip', 'user', pd.Grouper(key='exec_time', freq=time_window)])['exec_time'].transform('count')
        # 选择连续出现次数大于等于5的记录
        result = df[df['count'] >= num]
        result.drop_duplicates(subset=['ip'], keep='first', inplace=True)
        for index, row in result.iterrows():
            self.write_result(row['ip'], row['exec_time'].strftime('%m-%d %H:%M:%S').lstrip('0'), row['user'], 'Abnormal number of login failures')

    # 写入结果
    def write_result(self, ip, exec_time, user, type):
        if ip in self.white_list['ip']: return
        if ip not in self.result.keys():
            self.result[ip] = {'exec_time': exec_time, 'user': user, 'type': type, 'id': self.ftp_user.get(user, 0)}
        else:
            self.result[ip]['exec_time'] = exec_time
            if type not in self.result[ip]['type']:
                self.result[ip]['type'] += ',{}'.format(type)

    # 设置白名单
    def set_white_list(self, get):
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)

        # 校验参数
        try:
            get.validate([
                Param('ip').String(),
                Param('type').String(),

            ], [
                public.validate.trim_filter(),
            ])
        except Exception as ex:
            public.print_log("error info: {}".format(ex))
            return public.return_message(-1, 0, str(ex))


        try:
            if not hasattr(get, 'type') or not hasattr(get, 'ip'):
                return public.returnMsg(False, public.lang("The parameter is incorrect！"))
            if get.type == 'add':
                if get.ip in self.white_list['ip']: return public.return_message(0, 0, public.lang("successfully set"))
                self.white_list['ip'].append(get.ip)
            if get.type == 'del':
                if get.ip not in self.white_list['ip']: return public.return_message(0, 0, public.lang("successfully set"))
                self.white_list['ip'].remove(get.ip)
            public.writeFile(self.white_list_path, json.dumps(self.white_list))
            return public.return_message(0, 0, public.lang("successfully set"))
        except:
            return public.return_message(-1, 0, public.lang("failed set"))

    def get_white_list(self, get):
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)
        if os.path.exists(self.white_list_path):
            white_list = json.loads(public.readFile(self.white_list_path))
            #
        else:
            white_list = {'ip': ['127.0.0.1']}
        return public.return_message(0,0,white_list)

    # 获取登录失败数据
    def parse_log(self, file_list, day, username):
        result = []
        for file in file_list:
            if file['time'] < day: continue
            if not os.path.isfile(file['file']): continue
            log = public.readFile(file['file'])
            log = log.strip().split('\n')
            for line in log:
                if 'Authentication failed for user' not in line: continue
                l = {}
                hostname = line.split()[-1]
                exec_time = line.split(hostname)[0].strip()
                l['exec_time'] = self.get_format_time(exec_time)
                l['exec_time'] = str(datetime.datetime.now().year) + '-' + l['exec_time']
                a_time = int(datetime.datetime.strptime(l['exec_time'], '%Y-%m-%d %H:%M:%S').timestamp())
                if a_time < day: continue
                l['ip'] = line[line.find('(') + 1:line.find(')')].split('@')[1]
                l['user'] = line[line.find('(') + 1:line.find(')')].split('@')[0]
                if username and l['user'] not in username: continue
                l['status'] = False
                # 返回一个字典
                if len(l) >= 4:
                    result.append(l)
        return result

    # 设置自动任务
    def set_cron_task(self, get):
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)

        # 校验参数
        try:
            get.validate([
                Param('cycle').Integer(),
                Param('status').Integer(),
                Param('task_type').String(),
                Param('channel').String(),

            ], [
                public.validate.trim_filter(),
            ])
        except Exception as ex:
            public.print_log("error info: {}".format(ex))
            return public.return_message(-1, 0, str(ex))


        try:
            if not hasattr(get, 'task_type') or not hasattr(get, 'cycle') or not hasattr(get, 'status') or not hasattr(get, 'channel'):
                return public.return_message(-1, 0, public.lang("The parameter is incorrect！"))
            config = self.get_analysis_config(None)['message']
            if int(get.status) == 1:
                config['cron_task_status'] = 1
                self.add_cron_task(get.cycle)
                config['cron_task'] = {'task_type': json.loads(get.task_type), 'cycle': int(get.cycle), 'channel': get.channel}
            else:
                if 'cron_task' in config.keys():
                    del config['cron_task']
                config['cron_task_status'] = 0
                self.del_cron_task()
            public.writeFile(self.analysis_config_path, json.dumps(config))
            return public.return_message(0, 0, public.lang("successfully set"))
        except:
            return public.return_message(-1, 0, public.lang("failed set"))

    # 添加计划任务
    def add_cron_task(self, day):
        name = '[Do not delete] FTP audit log cutting task'
        if not public.M('crontab').where('name=?', (name,)).count():
            args = {
                "name": name,
                "type": 'day-n',
                "where1": day,
                "hour": '0',
                "minute": '0',
                "sName": "",
                "sType": 'toShell',
                "notice": '0',
                "notice_channel": '',
                "save": '',
                "save_local": '1',
                "backupTo": '',
                "sBody": 'btpython /www/server/panel/script/ftp_log_analysis.py',
                "urladdress": ''
            }
            res = crontab.crontab().AddCrontab(args)
            if res and "id" in res.keys():
                return True
            return False
        return True

    # 删除计划任务
    def del_cron_task(self):
        name = '[Do not delete] FTP audit log cutting task'
        id = public.M('crontab').where("name=?", (name,)).getField('id')
        args = {"id": id}
        crontab.crontab().DelCrontab(args)

    def ftp_users(self, get):
        if not self.__check_auth():
            return public.return_message(-1,0, self.__AUTH_MSG)
        usrername = public.M('ftps').field('name').select()
        return public.return_message(0,0,[i['name'] for i in usrername])

    # 转换debian时间戳
    def convert_timestamp(self, debian_timestamp):
        """
            将 Debian 时间戳转换为传统时间戳格式
        """
        # 定义 Debian 时间戳的格式
        debian_format = "%Y-%m-%dT%H:%M:%S.%f%z"
        # 定义传统时间戳
        ubuntu_format = "%b %d %H:%M:%S"
        dt = datetime.datetime.strptime(debian_timestamp, debian_format)
        ubuntu_timestamp = dt.strftime(ubuntu_format)
        return ubuntu_timestamp

    #  验证时间字符串是否符合 ISO 8601 标准
    def is_iso8601(self, time_str):
        """
        验证时间字符串是否符合 ISO 8601 标准。
        :param time_str: 输入的时间字符串
        :return: 如果符合 ISO 8601 标准，返回 True；否则返回 False
        """
        # ISO 8601 标准的正则表达式
        iso8601_regex = re.compile(
            r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?([+-]\d{2}:\d{2}|Z)?$'
        )
        return bool(iso8601_regex.match(time_str))
