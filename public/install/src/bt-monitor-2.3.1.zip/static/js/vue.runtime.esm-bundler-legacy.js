System.register(["./naive-ui-legacy.js","./vue-legacy.js"],(function(e,t){"use strict";var n,u;return{setters:[function(e){n=e.Z},function(e){u=e.ag}],execute:function(){e("r",n(u))}}}));
