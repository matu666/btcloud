#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, sys, time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.c_loader.PluginLoader as plugin_loader

# import core.include.monitor_db_manager as monitor_db_manager

monitor_db_manager = plugin_loader.get_module('/www/server/bt-monitor/core/include/monitor_db_manager.py')

if __name__ == '__main__':
    servers = []

    with monitor_db_manager.db_mgr() as db:
        servers = db.query()\
            .name('servers')\
            .where_in('status', [0, 1])\
            .column('sid')

    # 获取上个月1号00:00:00时间 - 1
    now_time = time.localtime()
    end_time = None

    if now_time.tm_mon > 1:
        end_time = int(time.mktime((now_time.tm_year, now_time.tm_mon - 1, 1, 0, 0, 0, 0, 0, 0))) - 1
    else:
        end_time = int(time.mktime((now_time.tm_year - 1, 12, 1, 0, 0, 0, 0, 0, 0))) - 1

    # 获取前天23:59:59时间
    end_time_day = int(time.mktime((now_time.tm_year, now_time.tm_mon, now_time.tm_mday - 1, 0, 0, 0, 0, 0, 0))) - 1

    # 开始归档
    s_time = time.time()
    print('|--开始归档数据库文件')
    for sid in servers:
        obj = monitor_db_manager.MonitorDbManager(sid)
        obj.archive(end_time=end_time)
        obj.archive(end_time=end_time_day, archive_type='process')

    print('|--数据库文件归档成功 耗时：{}s'.format(time.time() - s_time))