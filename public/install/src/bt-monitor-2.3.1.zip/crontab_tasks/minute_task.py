import os
import sys
import json
from wsgiref.simple_server import server_version

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
from core.include.monitor_helpers import warning_obj

def check_port_connection():
	"""检查在线主机端口是否可连接"""

	server_list = public.db_monitor("servers").where("status=?", (1,)).select()
	for sobj in server_list:
		sid = sobj["sid"]
		sip = sobj["ip"]
		select_res = public.db_monitor("server_details").field("port_info")\
			.where("sid=?", (sid,)).select()
		if not select_res: continue
		port_info = json.loads(select_res[0]["port_info"])
		for item in port_info:
			port = item["listen_port"]
			opened, test_method= warning_obj.test_port_connection(sip, port)
			keys = "sid,ip,port,test_method,ok"
			params = [sid, sip, port, test_method, opened]
			public.db_monitor("port_connection_logs").add(keys=keys, param=params)


if __name__ == "__main__":
	check_port_connection()